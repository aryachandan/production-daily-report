# Building the Production Daily Report APK

Due to sandbox environment limitations, the APK must be built on a local machine with Android SDK installed. Follow these instructions to build the APK on your computer.

## Prerequisites

Before building, ensure you have the following installed:

### Required Software

1. **Java Development Kit (JDK) 17+**
   - Download from: https://www.oracle.com/java/technologies/downloads/
   - Verify: `java -version` should show version 17 or higher

2. **Android SDK**
   - Download Android Studio from: https://developer.android.com/studio
   - Or download SDK command-line tools from: https://developer.android.com/studio#downloads

3. **Gradle 8.0+**
   - Usually included with Android Studio
   - Verify: `gradle --version`

4. **Git** (to clone the project)
   - Download from: https://git-scm.com/

### Environment Variables

Set these environment variables on your system:

**Windows:**
```
JAVA_HOME=C:\Program Files\Java\jdk-17
ANDROID_HOME=C:\Users\YourUsername\AppData\Local\Android\Sdk
PATH=%JAVA_HOME%\bin;%ANDROID_HOME%\tools;%ANDROID_HOME%\platform-tools;%PATH%
```

**macOS/Linux:**
```bash
export JAVA_HOME=/path/to/jdk-17
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$JAVA_HOME/bin:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools:$PATH
```

## Building the APK

### Step 1: Clone or Extract the Project

If you have the project files:

```bash
cd /path/to/ProductionDailyReport
```

Or clone from git:

```bash
git clone <repository-url>
cd ProductionDailyReport
```

### Step 2: Build Debug APK

The debug APK is suitable for testing and development:

```bash
./gradlew assembleDebug
```

**Output location:**
```
app/build/outputs/apk/debug/app-debug.apk
```

**Build time:** 3-5 minutes (first build may take longer)

### Step 3: Build Release APK

The release APK is optimized and ready for distribution:

```bash
./gradlew assembleRelease
```

**Output location:**
```
app/build/outputs/apk/release/app-release.apk
```

**Note:** Release builds require signing. See "Signing the APK" section below.

## Signing the APK

### For Debug APK

Debug APKs are automatically signed with the debug keystore. No additional steps needed.

### For Release APK

To create a signed release APK:

#### Step 1: Create a Keystore (one-time)

```bash
keytool -genkey -v -keystore production-daily-report.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias production-daily-report
```

You'll be prompted to enter:
- Keystore password
- Key password
- Your name, organization, etc.

**Save the keystore file safely!** You'll need it for future updates.

#### Step 2: Sign the Release APK

Create a `keystore.properties` file in the project root:

```properties
storeFile=production-daily-report.keystore
storePassword=YOUR_KEYSTORE_PASSWORD
keyAlias=production-daily-report
keyPassword=YOUR_KEY_PASSWORD
```

Then build:

```bash
./gradlew assembleRelease
```

The signed APK will be at:
```
app/build/outputs/apk/release/app-release.apk
```

## Installing and Testing the APK

### On Android Device (USB Connected)

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### On Android Emulator

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Manual Installation

1. Transfer the APK file to your Android device
2. Open a file manager on the device
3. Locate and tap the APK file
4. Tap "Install"
5. Grant permissions if prompted
6. Launch the app

## Troubleshooting

### Build Fails with "Could not find android.jar"

**Solution:** Download Android SDK API 34
```bash
sdkmanager "platforms;android-34"
```

### Build Fails with "Could not find tools.jar"

**Solution:** Ensure JAVA_HOME is set correctly and points to JDK (not JRE)

### Build Fails with "Gradle daemon exited unexpectedly"

**Solution:** Clean and rebuild
```bash
./gradlew clean
./gradlew assembleDebug
```

### APK Installation Fails with "App not installed"

**Possible causes:**
1. Insufficient storage on device
2. APK is corrupted (try rebuilding)
3. Device has older Android version (requires API 24+)
4. Conflicting app version already installed (uninstall first)

**Solution:**
```bash
adb uninstall com.production.dailyreport
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Build Fails with "Unsupported class-file format"

**Solution:** Ensure you're using Java 17+
```bash
java -version
# Should show version 17 or higher
```

## Build Variants

### Debug Build (Recommended for Testing)

```bash
./gradlew assembleDebug
```

**Characteristics:**
- Debuggable
- Includes debug symbols
- Larger file size
- Faster build time
- Can be installed alongside release version

### Release Build (For Distribution)

```bash
./gradlew assembleRelease
```

**Characteristics:**
- Optimized with ProGuard/R8
- Smaller file size
- Faster runtime
- Must be signed
- Ready for Google Play Store

## Advanced Build Options

### Build with Specific Build Type

```bash
./gradlew assemble[BuildType]
# Example: ./gradlew assembleDebug
```

### Build with Specific Flavor (if configured)

```bash
./gradlew assemble[Flavor][BuildType]
```

### Clean Build

```bash
./gradlew clean assembleDebug
```

### Build with Verbose Output

```bash
./gradlew assembleDebug --info
```

### Build with Stack Trace

```bash
./gradlew assembleDebug --stacktrace
```

## Continuous Integration

For CI/CD pipelines (GitHub Actions, Jenkins, etc.):

```bash
# Install dependencies
./gradlew dependencies

# Run tests
./gradlew test

# Build APK
./gradlew assembleDebug

# Build and sign release
./gradlew assembleRelease
```

## APK File Information

### Debug APK
- **File:** app-debug.apk
- **Size:** ~15-20 MB
- **Signature:** Debug keystore (auto-generated)
- **Use:** Testing and development

### Release APK
- **File:** app-release.apk
- **Size:** ~8-12 MB (optimized)
- **Signature:** Custom keystore (required)
- **Use:** Distribution and Google Play Store

## Publishing to Google Play Store

1. **Create Google Play Developer Account**
   - Visit: https://play.google.com/console
   - Pay one-time fee ($25)

2. **Create App Listing**
   - App name, description, screenshots
   - Category, content rating, etc.

3. **Upload Signed APK**
   - Upload app-release.apk
   - Add release notes

4. **Review and Publish**
   - Google reviews your app
   - Publish when approved

## Support

For build issues or questions:

1. Check the Gradle documentation: https://docs.gradle.org/
2. Check Android documentation: https://developer.android.com/docs
3. Review the project README.md
4. Check TESTING_GUIDE.md for troubleshooting

## Next Steps

After building the APK:

1. **Test on Device:** Install and test all features
2. **Follow Testing Guide:** Use TESTING_GUIDE.md checklist
3. **Gather Feedback:** Test with actual users
4. **Fix Issues:** Address any bugs found
5. **Build Release:** Create signed release APK
6. **Publish:** Share or publish to Google Play Store

---

**Version:** 2.0.0  
**Last Updated:** 2026-03-05  
**Build System:** Gradle 8.0+  
**Android SDK:** API 34 (target), API 24 (minimum)
