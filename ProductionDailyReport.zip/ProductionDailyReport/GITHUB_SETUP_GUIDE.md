# GitHub Actions से APK बनाने का गाइड

यह गाइड आपको step-by-step बताएगी कि कैसे GitHub Actions से automatically APK build करें।

## Step 1: GitHub Account बनाएँ

1. जाएँ: https://github.com
2. **Sign up** बटन दबाएँ
3. Email, username, password enter करें
4. Email verify करें
5. Done! ✅

## Step 2: नया Repository बनाएँ

1. GitHub पर login करें
2. Top right में **+** icon दबाएँ
3. **New repository** select करें
4. Repository details भरें:
   - **Repository name**: `production-daily-report`
   - **Description**: `Production Daily Report for Textile Factory`
   - **Visibility**: Public (या Private)
   - **.gitignore**: Android select करें
   - **License**: MIT (optional)
5. **Create repository** बटन दबाएँ

## Step 3: Project को GitHub पर Upload करें

### अपने कंप्यूटर पर Terminal खोलें

**Windows**: Command Prompt या PowerShell  
**Mac/Linux**: Terminal

### Commands चलाएँ:

```bash
# Project folder में जाएँ
cd /path/to/ProductionDailyReport

# Git initialize करें (अगर पहले से नहीं है)
git init

# सब files add करें
git add .

# पहली commit करें
git commit -m "Initial commit: Production Daily Report v2.0"

# Remote repository add करें
git remote add origin https://github.com/YOUR_USERNAME/production-daily-report.git

# Branch का नाम main करें
git branch -M main

# GitHub पर push करें
git push -u origin main
```

**Note**: `YOUR_USERNAME` को अपने GitHub username से replace करें

### GitHub पर Password/Token की जरूरत होगी

**Personal Access Token बनाएँ:**

1. GitHub पर Settings जाएँ (top right में profile icon → Settings)
2. बाएँ side में **Developer settings** खोलें
3. **Personal access tokens** → **Tokens (classic)** खोलें
4. **Generate new token** दबाएँ
5. Token को name दें: `github-actions-build`
6. Scopes select करें:
   - ✅ repo (सब कुछ)
   - ✅ workflow
7. **Generate token** दबाएँ
8. Token को **copy करके safe जगह save करें** (दोबारा नहीं दिखेगा!)

### Git push करते समय:

```bash
git push -u origin main
```

जब password माँगे तो:
- **Username**: अपना GitHub username
- **Password**: अभी बनाया हुआ Personal Access Token

## Step 4: GitHub Actions Workflow Check करें

1. GitHub repo खोलें
2. **Actions** tab दबाएँ
3. आपको "Build Production Daily Report APK" workflow दिखेगा
4. यह automatically चलना शुरू हो जाएगा

## Step 5: APK Download करें

### Build Complete होने का इंतज़ार करें

1. **Actions** tab में जाएँ
2. Latest build को देखें (green checkmark = success ✅)
3. Build पर click करें
4. नीचे **Artifacts** section में देखें:
   - `Production-Daily-Report-Debug` - Debug APK
   - `Production-Daily-Report-Release` - Release APK

5. APK पर click करके download करें

## Step 6: APK को Android Device पर Install करें

### Option 1: USB से Install करें

```bash
# APK को अपने कंप्यूटर पर download करें
# फिर यह command चलाएँ:

adb install Production-Daily-Report-Debug.apk
```

### Option 2: Manual Install करें

1. APK को अपने phone में transfer करें (email, WhatsApp, etc.)
2. Phone पर file manager खोलें
3. APK file को tap करें
4. **Install** दबाएँ
5. App खुल जाएगा!

## GitHub Actions Workflow क्या करता है?

Workflow file (`.github/workflows/build-apk.yml`) यह करता है:

1. **Code checkout करता है** - GitHub से latest code लेता है
2. **Java 17 setup करता है** - Build के लिए
3. **Gradle cache करता है** - Build को faster बनाता है
4. **Debug APK build करता है** - Testing के लिए
5. **Release APK build करता है** - Distribution के लिए
6. **APK upload करता है** - Download के लिए artifacts में
7. **Build report generate करता है** - Status दिखाने के लिए

## Automatic Builds कब होते हैं?

Workflow automatically चलता है जब:

1. **Code push करो** - `main`, `master`, या `develop` branch पर
2. **Pull request बनाओ** - किसी भी branch से
3. **Manually trigger करो** - "Run workflow" button से

## Build Status Check करें

### Success (✅ Green)
- APK successfully build हुआ
- Artifacts download के लिए ready हैं

### Failed (❌ Red)
- कोई error आया
- Logs में error message देखें
- Fix करके फिर से push करें

## Logs देखें

अगर build fail हो:

1. **Actions** tab खोलें
2. Failed build पर click करें
3. **Build with Gradle** step खोलें
4. Error message देखें
5. Fix करके फिर से push करें

## Release APK को Sign करें (Advanced)

Release APK को Google Play Store पर publish करने के लिए signing की जरूरत है।

### Keystore बनाएँ:

```bash
keytool -genkey -v -keystore production-daily-report.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias production-daily-report
```

### GitHub Secrets में Add करें:

1. GitHub repo → **Settings** → **Secrets and variables** → **Actions**
2. **New repository secret** दबाएँ
3. यह secrets add करें:
   - `KEYSTORE_FILE`: keystore file का base64 encoded content
   - `KEYSTORE_PASSWORD`: keystore password
   - `KEY_ALIAS`: key alias
   - `KEY_PASSWORD`: key password

### Keystore को Base64 में Convert करें:

**Windows:**
```bash
certutil -encode production-daily-report.keystore keystore.txt
```

**Mac/Linux:**
```bash
base64 production-daily-report.keystore
```

## Tips & Tricks

### Build को Manually Trigger करें

1. **Actions** tab खोलें
2. "Build Production Daily Report APK" workflow select करें
3. **Run workflow** दबाएँ
4. **Run workflow** फिर से दबाएँ

### Build को Disable करें

1. Workflow file को edit करें (`.github/workflows/build-apk.yml`)
2. Top पर `on:` section को comment करें
3. Commit और push करें

### Artifacts को Longer रखें

Workflow file में `retention-days` को बदलें:

```yaml
retention-days: 30  # 30 दिन तक रखेगा
```

## Troubleshooting

### Build Fails: "Could not find android.jar"

**Solution**: Workflow automatically Android SDK download करता है। कुछ बार timeout हो सकता है। फिर से run करें।

### Build Fails: "Gradle daemon exited"

**Solution**: यह temporary issue है। फिर से run करें।

### APK Download नहीं हो रहा

**Solution**: 
1. Build successful है कि नहीं check करें (green checkmark)
2. Artifacts section में देखें
3. 30 दिन के बाद artifacts delete हो जाते हैं

### GitHub Push नहीं हो रहा

**Solution**:
1. Personal Access Token correct है कि नहीं check करें
2. Token को copy-paste करते समय space न जोड़ें
3. Token को regenerate करें

## Next Steps

1. ✅ GitHub पर code upload करें
2. ✅ GitHub Actions से APK build करें
3. ✅ APK download करें
4. ✅ Android device पर install करें
5. ✅ Testing करें
6. ✅ Features को improve करें
7. ✅ Google Play Store पर publish करें (optional)

## Important Notes

- **Debug APK**: Testing के लिए, कोई signing नहीं
- **Release APK**: Distribution के लिए, signing की जरूरत है
- **Artifacts**: 30 दिन तक available रहते हैं
- **Free**: GitHub Actions 2000 minutes/month free देता है

## Support

अगर कोई problem हो:

1. GitHub Actions logs देखें
2. Error message को Google करें
3. GitHub documentation: https://docs.github.com/actions
4. Android documentation: https://developer.android.com

---

**Happy Building! 🚀**

अब आप GitHub Actions से automatically APK build कर सकते हो!
