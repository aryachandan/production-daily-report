# Production Daily Report - Testing & Build Guide

## Phase 14: Testing & Delivery Checklist

### 1. Core Functionality Testing

#### Splash & Onboarding Flow
- [ ] Splash screen displays for 1.5 seconds
- [ ] Onboarding shows 3 slides with smooth transitions
- [ ] SKIP button skips to Home
- [ ] GET STARTED button completes onboarding
- [ ] Returning users skip directly to Home

#### Home Screen
- [ ] Report cards display with creation date and time
- [ ] FAB button opens Create Report screen
- [ ] History button navigates to History screen
- [ ] Settings button navigates to Settings screen
- [ ] Summary button navigates to Generate Summary screen
- [ ] Empty state message shows when no reports exist
- [ ] "Set All Dates to Today" button works correctly

#### Create Report Screen
- [ ] Step 1: Select page from dropdown
- [ ] Step 2: Multi-select machines (Select All/Clear buttons work)
- [ ] Step 3: Multi-select shifts (Select All/Clear buttons work)
- [ ] Step 4: Review shows selected items
- [ ] Save button creates new report and navigates to Data Entry
- [ ] Back button navigates between steps
- [ ] Form validation prevents saving with empty selections

#### Data Entry Screen
- [ ] Dynamic table displays machines × shifts
- [ ] Number inputs accept only numeric values
- [ ] Auto-calculations update in real-time:
  - [ ] Machine totals (sum of shifts)
  - [ ] Shift totals (sum of machines)
  - [ ] Grand total (sum of all)
- [ ] Remark toggle shows/hides remark column
- [ ] Remarks are saved with entries
- [ ] CLEAR button resets all data with confirmation
- [ ] SAVE button persists data to database
- [ ] PDF button generates and shares PDF
- [ ] SHARE button opens share chooser for image

#### History Screen
- [ ] Reports list shows all past entries sorted by date (newest first)
- [ ] Tap report card opens Data Entry screen for viewing/editing
- [ ] Delete button removes entry with confirmation dialog
- [ ] Empty state shows when no history exists
- [ ] Date filtering works correctly

#### Settings Screen
- [ ] Pages Tab: Add/Edit/Delete pages
- [ ] Machines Tab: Add/Edit/Delete machines
- [ ] Shifts Tab: Add/Edit/Delete shifts
- [ ] Cleanup Tab: Delete entries by date range
- [ ] Reminders Tab: Enable/disable reminders, set time
- [ ] All CRUD operations persist to database
- [ ] Dialogs appear/disappear smoothly

#### Generate Summary Screen
- [ ] Date range selector works (Custom/Monthly/Yearly)
- [ ] Machine multi-select with Select All/Clear
- [ ] Shift multi-select with Select All/Clear
- [ ] Generate button creates summary table
- [ ] Summary shows: Machine, Shift, Total, Days, Avg/Day
- [ ] Grand total row highlights correctly
- [ ] PDF export generates summary PDF
- [ ] SHARE button opens share chooser

### 2. Export & Sharing Testing

#### PDF Export
- [ ] PDF generates without errors
- [ ] PDF contains report header (company name, date, timestamp)
- [ ] Table formatting is clean and readable
- [ ] Remarks section appears (if non-empty)
- [ ] File saves to correct directory
- [ ] PDF can be opened in external viewer

#### Image Export
- [ ] PNG image generates without errors
- [ ] Image resolution is 1080px+ width
- [ ] Table formatting matches PDF
- [ ] Image can be shared via WhatsApp
- [ ] Image can be shared via Email
- [ ] Image can be shared via Telegram
- [ ] File saves to correct directory

#### Share Sheet
- [ ] Android Share Sheet opens on SHARE button tap
- [ ] Multiple apps appear in share chooser
- [ ] Sharing to WhatsApp works
- [ ] Sharing to Email works
- [ ] Sharing to Telegram works
- [ ] File is properly attached to message

### 3. Database & Persistence Testing

#### Data Persistence
- [ ] Data survives app restart
- [ ] Multiple reports can be created
- [ ] Each report has unique ID
- [ ] Timestamps are accurate
- [ ] Remarks are saved and retrieved
- [ ] Deleted entries are removed from database

#### Default Data
- [ ] 6 pages pre-populated on first launch
- [ ] 23 machines pre-populated
- [ ] 2 shifts pre-populated
- [ ] Default data appears in dropdowns/lists

### 4. Notifications Testing

#### Daily Reminders
- [ ] Reminder toggle works in Settings
- [ ] Time picker allows hour/minute selection
- [ ] Selected time is saved
- [ ] Notification appears at scheduled time
- [ ] Notification text is clear and actionable
- [ ] Tapping notification opens app to Home
- [ ] Reminder repeats daily at set time
- [ ] Disabling reminder stops notifications

### 5. UI/UX Testing

#### Animations
- [ ] Screen transitions are smooth
- [ ] Button press animations work (scale 0.95)
- [ ] Card entrance animations are subtle
- [ ] Loading indicators animate smoothly
- [ ] Expand/collapse animations work

#### Dark Mode
- [ ] App respects system dark mode setting
- [ ] Colors are readable in dark mode
- [ ] All screens support dark mode
- [ ] Transitions between modes are smooth

#### Responsive Design
- [ ] App works on small screens (API 24)
- [ ] App works on large screens
- [ ] Landscape orientation supported
- [ ] No text clipping or overflow
- [ ] Buttons are easily tappable (48dp minimum)

#### Material Design 3
- [ ] Primary color (deep blue) applied correctly
- [ ] Typography follows Material Design
- [ ] Spacing and padding are consistent
- [ ] Shadows and elevation work correctly
- [ ] Ripple effects on interactive elements

### 6. Error Handling Testing

#### Input Validation
- [ ] Empty fields show error messages
- [ ] Invalid inputs are rejected
- [ ] Numeric fields reject non-numeric input
- [ ] Date selection is validated

#### Error States
- [ ] Database errors show user-friendly messages
- [ ] File I/O errors are handled gracefully
- [ ] Permission errors show appropriate dialogs
- [ ] Network errors (if applicable) are handled

### 7. Performance Testing

#### App Launch
- [ ] Splash screen appears within 1 second
- [ ] App fully loads within 3 seconds
- [ ] No ANR (Application Not Responding) errors

#### Data Operations
- [ ] Creating report completes in < 1 second
- [ ] Saving data completes in < 500ms
- [ ] Loading history completes in < 1 second
- [ ] PDF generation completes in < 3 seconds
- [ ] Image generation completes in < 2 seconds

#### Memory Usage
- [ ] App doesn't crash with large datasets
- [ ] Memory usage stays reasonable during normal use
- [ ] No memory leaks detected

### 8. Device & Version Testing

#### Android Versions
- [ ] Tested on API 24 (Android 7.0) - minimum
- [ ] Tested on API 28 (Android 9.0)
- [ ] Tested on API 31 (Android 12.0)
- [ ] Tested on API 34 (Android 14.0) - target

#### Permissions
- [ ] POST_NOTIFICATIONS permission requested (Android 13+)
- [ ] File access permissions work correctly
- [ ] Permission denial handled gracefully

### 9. Build & Release

#### Debug Build
- [ ] `./gradlew assembleDebug` completes successfully
- [ ] APK installs on test device
- [ ] App launches without crashes
- [ ] All features work as expected

#### Release Build
- [ ] `./gradlew assembleRelease` completes successfully
- [ ] APK is properly signed
- [ ] APK size is reasonable (< 50MB)
- [ ] ProGuard/R8 obfuscation works
- [ ] App runs smoothly on release build

#### APK Verification
- [ ] APK can be installed on multiple devices
- [ ] App signature is valid
- [ ] Version code/name are correct
- [ ] App icon displays correctly

## Build Instructions

### Prerequisites
- Android SDK API 34 installed
- Gradle 8.0+ installed
- Java 17 installed
- Kotlin 1.9.22 installed

### Building Debug APK
```bash
cd /home/ubuntu/ProductionDailyReport
./gradlew assembleDebug
# APK location: app/build/outputs/apk/debug/app-debug.apk
```

### Building Release APK
```bash
cd /home/ubuntu/ProductionDailyReport
./gradlew assembleRelease
# APK location: app/build/outputs/apk/release/app-release.apk
```

### Installing APK
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Running on Emulator
```bash
./gradlew installDebug
./gradlew runDebug
```

## Known Limitations & Future Enhancements

### Current Limitations
1. No cloud sync - data is local only
2. No user authentication
3. No multi-user support
4. No backup/restore functionality

### Future Enhancements
1. Cloud backup with Firebase
2. User authentication and accounts
3. Multi-device sync
4. Advanced analytics and charts
5. Offline-first sync when online
6. Custom report templates
7. Data export to Excel/CSV
8. Biometric authentication

## Troubleshooting

### Common Issues

**App crashes on startup**
- Clear app data: `adb shell pm clear com.production.dailyreport`
- Reinstall: `adb uninstall com.production.dailyreport && ./gradlew installDebug`

**Database errors**
- Delete database: `adb shell rm /data/data/com.production.dailyreport/databases/*`
- Restart app to recreate with default data

**Notification not appearing**
- Check notification settings in Android Settings
- Verify POST_NOTIFICATIONS permission is granted
- Check WorkManager logs: `adb logcat | grep WorkManager`

**PDF/Image export fails**
- Check file permissions: `adb shell pm grant com.production.dailyreport android.permission.WRITE_EXTERNAL_STORAGE`
- Verify storage space is available

**Share not working**
- Ensure target app (WhatsApp, Email, etc.) is installed
- Check file provider configuration in AndroidManifest.xml

## Contact & Support

For issues or questions, please refer to the README.md file or contact the development team.
