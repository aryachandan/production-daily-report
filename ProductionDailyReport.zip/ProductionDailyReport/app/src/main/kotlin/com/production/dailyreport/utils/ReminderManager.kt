package com.production.dailyreport.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.work.BackoffPolicy
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.production.dailyreport.workers.NotificationWorker
import java.util.Calendar
import java.util.concurrent.TimeUnit

object ReminderManager {

    private const val PREFS_NAME = "reminder_prefs"
    private const val KEY_REMINDER_ENABLED = "reminder_enabled"
    private const val KEY_REMINDER_HOUR = "reminder_hour"
    private const val KEY_REMINDER_MINUTE = "reminder_minute"

    fun isReminderEnabled(context: Context): Boolean {
        val prefs = getPreferences(context)
        return prefs.getBoolean(KEY_REMINDER_ENABLED, false)
    }

    fun setReminderEnabled(context: Context, enabled: Boolean) {
        val prefs = getPreferences(context)
        prefs.edit().putBoolean(KEY_REMINDER_ENABLED, enabled).apply()

        if (enabled) {
            val hour = prefs.getInt(KEY_REMINDER_HOUR, 8)
            val minute = prefs.getInt(KEY_REMINDER_MINUTE, 0)
            scheduleReminder(context, hour, minute)
        } else {
            cancelReminder(context)
        }
    }

    fun getReminderTime(context: Context): Pair<Int, Int> {
        val prefs = getPreferences(context)
        val hour = prefs.getInt(KEY_REMINDER_HOUR, 8)
        val minute = prefs.getInt(KEY_REMINDER_MINUTE, 0)
        return Pair(hour, minute)
    }

    fun setReminderTime(context: Context, hour: Int, minute: Int) {
        val prefs = getPreferences(context)
        prefs.edit().apply {
            putInt(KEY_REMINDER_HOUR, hour)
            putInt(KEY_REMINDER_MINUTE, minute)
        }.apply()

        // Reschedule if reminder is enabled
        if (isReminderEnabled(context)) {
            scheduleReminder(context, hour, minute)
        }
    }

    fun scheduleReminder(context: Context, hour: Int, minute: Int) {
        try {
            // Calculate initial delay
            val now = Calendar.getInstance()
            val scheduledTime = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
            }

            // If scheduled time is in the past, schedule for tomorrow
            if (scheduledTime.before(now)) {
                scheduledTime.add(Calendar.DAY_OF_MONTH, 1)
            }

            val initialDelay = scheduledTime.timeInMillis - now.timeInMillis

            // Create periodic work request (daily)
            val reminderWork = PeriodicWorkRequestBuilder<NotificationWorker>(
                1, // Repeat interval
                TimeUnit.DAYS
            ).apply {
                setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
                setBackoffPolicy(
                    BackoffPolicy.LINEAR,
                    PeriodicWorkRequestBuilder.MIN_BACKOFF_MILLIS,
                    TimeUnit.MILLISECONDS
                )
            }.build()

            // Schedule the work
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                NotificationWorker.WORKER_TAG,
                ExistingPeriodicWorkPolicy.KEEP,
                reminderWork
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun cancelReminder(context: Context) {
        try {
            WorkManager.getInstance(context).cancelUniqueWork(NotificationWorker.WORKER_TAG)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getPreferences(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun formatTime(hour: Int, minute: Int): String {
        return String.format("%02d:%02d", hour, minute)
    }
}
