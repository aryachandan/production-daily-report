package com.production.dailyreport.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.production.dailyreport.utils.AnimationUtils
import com.production.dailyreport.ui.screens.SplashScreen
import com.production.dailyreport.ui.screens.OnboardingScreen
import com.production.dailyreport.ui.screens.HomeScreen
import com.production.dailyreport.ui.screens.CreateReportScreen
import com.production.dailyreport.ui.screens.DataEntryScreen
import com.production.dailyreport.ui.screens.HistoryScreen
import com.production.dailyreport.ui.screens.SettingsScreen
import com.production.dailyreport.ui.screens.GenerateSummaryScreen

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Onboarding : Screen("onboarding")
    object Home : Screen("home")
    object CreateReport : Screen("create_report")
    object DataEntry : Screen("data_entry/{templateId}")
    object History : Screen("history")
    object HistoryDetail : Screen("history_detail/{templateId}")
    object Settings : Screen("settings")
    object GenerateSummary : Screen("generate_summary")
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(navController = navController)
        }
        
        composable(
            Screen.Onboarding.route,
            enterTransition = { AnimationUtils.slideInFromRight() },
            exitTransition = { AnimationUtils.slideOutToLeft() }
        ) {
            OnboardingScreen(navController = navController)
        }
        
        composable(
            Screen.Home.route,
            enterTransition = { AnimationUtils.slideInFromLeft() },
            exitTransition = { AnimationUtils.slideOutToRight() }
        ) {
            HomeScreen(navController = navController)
        }
        
        composable(
            Screen.CreateReport.route,
            enterTransition = { AnimationUtils.slideInFromBottom() },
            exitTransition = { AnimationUtils.slideOutToBottom() }
        ) {
            CreateReportScreen(navController = navController)
        }
        
        composable(
            Screen.DataEntry.route,
            enterTransition = { AnimationUtils.slideInFromRight() },
            exitTransition = { AnimationUtils.slideOutToLeft() }
        ) { backStackEntry ->
            val templateId = backStackEntry.arguments?.getString("templateId")?.toLongOrNull() ?: 0L
            DataEntryScreen(navController = navController, templateId = templateId)
        }
        
        composable(
            Screen.History.route,
            enterTransition = { AnimationUtils.slideInFromRight() },
            exitTransition = { AnimationUtils.slideOutToLeft() }
        ) {
            HistoryScreen(navController = navController)
        }
        
        composable(
            Screen.Settings.route,
            enterTransition = { AnimationUtils.slideInFromRight() },
            exitTransition = { AnimationUtils.slideOutToLeft() }
        ) {
            SettingsScreen(navController = navController)
        }
        
        composable(
            Screen.GenerateSummary.route,
            enterTransition = { AnimationUtils.slideInFromRight() },
            exitTransition = { AnimationUtils.slideOutToLeft() }
        ) {
            GenerateSummaryScreen(navController = navController)
        }
    }
}
