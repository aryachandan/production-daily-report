package com.production.dailyreport.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.production.dailyreport.data.db.MachineDao
import com.production.dailyreport.data.db.MachineEntity
import com.production.dailyreport.data.db.PageDao
import com.production.dailyreport.data.db.PageEntity
import com.production.dailyreport.data.db.ReportEntryDao
import com.production.dailyreport.data.db.ShiftDao
import com.production.dailyreport.data.db.ShiftEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import android.content.Context
import com.production.dailyreport.utils.ReminderManager

data class SettingsState(
    val pages: List<PageEntity> = emptyList(),
    val machines: List<MachineEntity> = emptyList(),
    val shifts: List<ShiftEntity> = emptyList(),
    val isLoading: Boolean = true,
    val selectedTab: Int = 0, // 0: Pages, 1: Machines, 2: Shifts, 3: Data Cleanup, 4: Reminders
    val showAddDialog: Boolean = false,
    val showDeleteDialog: Boolean = false,
    val selectedItemId: Long = 0L,
    val selectedItemName: String = "",
    val newItemName: String = "",
    val editingItemId: Long? = null,
    val cleanupDateRange: String = "90 days",
    val reminderEnabled: Boolean = false,
    val reminderHour: Int = 8,
    val reminderMinute: Int = 0,
    val showTimePickerDialog: Boolean = false
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val pageDao: PageDao,
    private val machineDao: MachineDao,
    private val shiftDao: ShiftDao,
    private val reportEntryDao: ReportEntryDao
) : ViewModel() {

    private val _state = MutableStateFlow(SettingsState())
    val state: StateFlow<SettingsState> = _state.asStateFlow()

    init {
        loadSettings()
    }

    private fun loadSettings() {
        viewModelScope.launch {
            try {
                _state.value = _state.value.copy(isLoading = true)
                val pages = pageDao.getAllPages()
                val machines = machineDao.getAllMachines()
                val shifts = shiftDao.getAllShifts()

                _state.value = _state.value.copy(
                    pages = pages,
                    machines = machines,
                    shifts = shifts,
                    isLoading = false
                )
            } catch (e: Exception) {
                e.printStackTrace()
                _state.value = _state.value.copy(isLoading = false)
            }
        }
    }

    fun selectTab(tabIndex: Int) {
        _state.value = _state.value.copy(selectedTab = tabIndex)
    }

    fun showAddDialog(itemType: String) {
        _state.value = _state.value.copy(
            showAddDialog = true,
            newItemName = "",
            editingItemId = null
        )
    }

    fun hideAddDialog() {
        _state.value = _state.value.copy(
            showAddDialog = false,
            newItemName = "",
            editingItemId = null
        )
    }

    fun updateNewItemName(name: String) {
        _state.value = _state.value.copy(newItemName = name)
    }

    fun showDeleteDialog(itemId: Long, itemName: String) {
        _state.value = _state.value.copy(
            showDeleteDialog = true,
            selectedItemId = itemId,
            selectedItemName = itemName
        )
    }

    fun hideDeleteDialog() {
        _state.value = _state.value.copy(
            showDeleteDialog = false,
            selectedItemId = 0L,
            selectedItemName = ""
        )
    }

    // Page Management
    fun addPage(pageName: String) {
        viewModelScope.launch {
            try {
                if (pageName.isNotBlank()) {
                    pageDao.insert(PageEntity(name = pageName))
                    loadSettings()
                    hideAddDialog()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun updatePage(pageId: Long, newName: String) {
        viewModelScope.launch {
            try {
                if (newName.isNotBlank()) {
                    val page = _state.value.pages.find { it.id == pageId }
                    if (page != null) {
                        pageDao.update(page.copy(name = newName))
                        loadSettings()
                        hideAddDialog()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun deletePage(pageId: Long) {
        viewModelScope.launch {
            try {
                pageDao.delete(pageId)
                loadSettings()
                hideDeleteDialog()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Machine Management
    fun addMachine(machineName: String) {
        viewModelScope.launch {
            try {
                if (machineName.isNotBlank()) {
                    machineDao.insert(MachineEntity(name = machineName))
                    loadSettings()
                    hideAddDialog()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun updateMachine(machineId: Long, newName: String) {
        viewModelScope.launch {
            try {
                if (newName.isNotBlank()) {
                    val machine = _state.value.machines.find { it.id == machineId }
                    if (machine != null) {
                        machineDao.update(machine.copy(name = newName))
                        loadSettings()
                        hideAddDialog()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun deleteMachine(machineId: Long) {
        viewModelScope.launch {
            try {
                machineDao.delete(machineId)
                loadSettings()
                hideDeleteDialog()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Shift Management
    fun addShift(shiftName: String) {
        viewModelScope.launch {
            try {
                if (shiftName.isNotBlank()) {
                    shiftDao.insert(ShiftEntity(name = shiftName))
                    loadSettings()
                    hideAddDialog()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun updateShift(shiftId: Long, newName: String) {
        viewModelScope.launch {
            try {
                if (newName.isNotBlank()) {
                    val shift = _state.value.shifts.find { it.id == shiftId }
                    if (shift != null) {
                        shiftDao.update(shift.copy(name = newName))
                        loadSettings()
                        hideAddDialog()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun deleteShift(shiftId: Long) {
        viewModelScope.launch {
            try {
                shiftDao.delete(shiftId)
                loadSettings()
                hideDeleteDialog()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Data Cleanup
    fun deleteEntriesOlderThan(days: Int) {
        viewModelScope.launch {
            try {
                val cutoffDate = System.currentTimeMillis() - (days * 24 * 60 * 60 * 1000L)
                reportEntryDao.deleteEntriesOlderThan(cutoffDate)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun setCleanupDateRange(range: String) {
        _state.value = _state.value.copy(cleanupDateRange = range)
    }

    fun startEditingItem(itemId: Long, currentName: String) {
        _state.value = _state.value.copy(
            editingItemId = itemId,
            newItemName = currentName,
            showAddDialog = true
        )
    }

    fun loadReminders(context: Context) {
        val enabled = ReminderManager.isReminderEnabled(context)
        val (hour, minute) = ReminderManager.getReminderTime(context)
        _state.value = _state.value.copy(
            reminderEnabled = enabled,
            reminderHour = hour,
            reminderMinute = minute
        )
    }

    fun toggleReminder(context: Context) {
        val newEnabled = !_state.value.reminderEnabled
        ReminderManager.setReminderEnabled(context, newEnabled)
        _state.value = _state.value.copy(reminderEnabled = newEnabled)
    }

    fun setReminderTime(context: Context, hour: Int, minute: Int) {
        ReminderManager.setReminderTime(context, hour, minute)
        _state.value = _state.value.copy(
            reminderHour = hour,
            reminderMinute = minute,
            showTimePickerDialog = false
        )
    }

    fun showTimePickerDialog() {
        _state.value = _state.value.copy(showTimePickerDialog = true)
    }

    fun hideTimePickerDialog() {
        _state.value = _state.value.copy(showTimePickerDialog = false)
    }
}
