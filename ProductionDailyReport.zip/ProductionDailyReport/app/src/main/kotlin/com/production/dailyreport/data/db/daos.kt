package com.production.dailyreport.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PageDao {
    @Insert
    suspend fun insert(page: PageEntity): Long

    @Update
    suspend fun update(page: PageEntity)

    @Delete
    suspend fun delete(page: PageEntity)

    @Query("SELECT * FROM pages ORDER BY displayOrder ASC")
    fun getAllPages(): Flow<List<PageEntity>>

    @Query("SELECT * FROM pages WHERE id = :id")
    suspend fun getPageById(id: Long): PageEntity?

    @Query("DELETE FROM pages WHERE id = :id")
    suspend fun deletePageById(id: Long)
}

@Dao
interface MachineDao {
    @Insert
    suspend fun insert(machine: MachineEntity): Long

    @Update
    suspend fun update(machine: MachineEntity)

    @Delete
    suspend fun delete(machine: MachineEntity)

    @Query("SELECT * FROM machines ORDER BY displayOrder ASC")
    fun getAllMachines(): Flow<List<MachineEntity>>

    @Query("SELECT * FROM machines WHERE id = :id")
    suspend fun getMachineById(id: Long): MachineEntity?

    @Query("DELETE FROM machines WHERE id = :id")
    suspend fun deleteMachineById(id: Long)
}

@Dao
interface ShiftDao {
    @Insert
    suspend fun insert(shift: ShiftEntity): Long

    @Update
    suspend fun update(shift: ShiftEntity)

    @Delete
    suspend fun delete(shift: ShiftEntity)

    @Query("SELECT * FROM shifts ORDER BY displayOrder ASC")
    fun getAllShifts(): Flow<List<ShiftEntity>>

    @Query("SELECT * FROM shifts WHERE id = :id")
    suspend fun getShiftById(id: Long): ShiftEntity?

    @Query("DELETE FROM shifts WHERE id = :id")
    suspend fun deleteShiftById(id: Long)
}

@Dao
interface ReportTemplateDao {
    @Insert
    suspend fun insert(template: ReportTemplateEntity): Long

    @Update
    suspend fun update(template: ReportTemplateEntity)

    @Delete
    suspend fun delete(template: ReportTemplateEntity)

    @Query("SELECT * FROM report_templates ORDER BY createdAt DESC")
    fun getAllTemplates(): Flow<List<ReportTemplateEntity>>

    @Query("SELECT * FROM report_templates WHERE id = :id")
    suspend fun getTemplateById(id: Long): ReportTemplateEntity?

    @Query("SELECT * FROM report_templates WHERE pageId = :pageId ORDER BY createdAt DESC")
    fun getTemplatesByPageId(pageId: Long): Flow<List<ReportTemplateEntity>>

    @Query("SELECT * FROM report_templates WHERE reportDate = :date ORDER BY createdAt DESC")
    fun getTemplatesByDate(date: String): Flow<List<ReportTemplateEntity>>

    @Query("DELETE FROM report_templates WHERE id = :id")
    suspend fun deleteTemplateById(id: Long)
}

@Dao
interface TemplateMachineDao {
    @Insert
    suspend fun insert(templateMachine: TemplateMachineEntity): Long

    @Query("SELECT * FROM template_machines WHERE templateId = :templateId ORDER BY displayOrder ASC")
    suspend fun getMachinesByTemplateId(templateId: Long): List<TemplateMachineEntity>

    @Query("DELETE FROM template_machines WHERE templateId = :templateId")
    suspend fun deleteByTemplateId(templateId: Long)
}

@Dao
interface TemplateMachineShiftDao {
    @Insert
    suspend fun insert(shift: TemplateMachineShiftEntity): Long

    @Query("SELECT * FROM template_machine_shifts WHERE templateMachineId = :templateMachineId")
    suspend fun getShiftsByTemplateMachineId(templateMachineId: Long): List<TemplateMachineShiftEntity>

    @Query("DELETE FROM template_machine_shifts WHERE templateMachineId = :templateMachineId")
    suspend fun deleteByTemplateMachineId(templateMachineId: Long)
}

@Dao
interface ReportEntryDao {
    @Insert
    suspend fun insert(entry: ReportEntryEntity): Long

    @Update
    suspend fun update(entry: ReportEntryEntity)

    @Delete
    suspend fun delete(entry: ReportEntryEntity)

    @Query("""
        SELECT * FROM report_entries 
        WHERE templateMachineShiftId = :templateMachineShiftId 
        AND reportDate = :reportDate
    """)
    suspend fun getEntry(templateMachineShiftId: Long, reportDate: String): ReportEntryEntity?

    @Query("""
        SELECT * FROM report_entries 
        WHERE reportDate = :reportDate
        ORDER BY savedAt DESC
    """)
    fun getEntriesByDate(reportDate: String): Flow<List<ReportEntryEntity>>

    @Query("""
        SELECT * FROM report_entries 
        WHERE reportDate BETWEEN :startDate AND :endDate
        ORDER BY reportDate DESC
    """)
    fun getEntriesByDateRange(startDate: String, endDate: String): Flow<List<ReportEntryEntity>>

    @Query("""
        DELETE FROM report_entries 
        WHERE reportDate < date('now', '-90 days')
    """)
    suspend fun deleteLast90DaysData()

    @Query("""
        DELETE FROM report_entries 
        WHERE reportDate BETWEEN :startDate AND :endDate
    """)
    suspend fun deleteByDateRange(startDate: String, endDate: String)

    @Query("DELETE FROM report_entries WHERE reportDate = :reportDate")
    suspend fun deleteByDate(reportDate: String)
}

@Dao
interface PageRemarkDao {
    @Insert
    suspend fun insert(remark: PageRemarkEntity): Long

    @Update
    suspend fun update(remark: PageRemarkEntity)

    @Query("""
        SELECT * FROM page_remarks 
        WHERE templateId = :templateId AND reportDate = :reportDate
    """)
    suspend fun getRemark(templateId: Long, reportDate: String): PageRemarkEntity?

    @Query("""
        DELETE FROM page_remarks 
        WHERE reportDate BETWEEN :startDate AND :endDate
    """)
    suspend fun deleteByDateRange(startDate: String, endDate: String)

    @Query("DELETE FROM page_remarks WHERE reportDate = :reportDate")
    suspend fun deleteByDate(reportDate: String)
}
