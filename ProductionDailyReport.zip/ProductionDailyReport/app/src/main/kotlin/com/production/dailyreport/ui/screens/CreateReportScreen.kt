package com.production.dailyreport.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.production.dailyreport.data.db.MachineEntity
import com.production.dailyreport.data.db.PageEntity
import com.production.dailyreport.data.db.ShiftEntity
import com.production.dailyreport.ui.navigation.Screen
import com.production.dailyreport.ui.viewmodels.CreateReportViewModel
import java.time.LocalDate

@Composable
fun CreateReportScreen(
    navController: NavHostController,
    viewModel: CreateReportViewModel = hiltViewModel()
) {
    var currentStep by remember { mutableStateOf(1) }
    var selectedPageId by remember { mutableStateOf<Long?>(null) }
    var reportHeading by remember { mutableStateOf("") }
    var reportDate by remember { mutableStateOf(LocalDate.now().toString()) }
    var selectedMachines by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var selectedShifts by remember { mutableStateOf<Map<Long, Set<Long>>>(emptyMap()) }

    val pages by viewModel.allPages.collectAsState(initial = emptyList())
    val machines by viewModel.allMachines.collectAsState(initial = emptyList())
    val shifts by viewModel.allShifts.collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Create Report - Step $currentStep/4") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            when (currentStep) {
                1 -> Step1BasicInfo(
                    pages = pages,
                    selectedPageId = selectedPageId,
                    onPageSelected = { selectedPageId = it },
                    reportHeading = reportHeading,
                    onHeadingChanged = { reportHeading = it },
                    reportDate = reportDate,
                    onDateChanged = { reportDate = it }
                )
                2 -> Step2SelectMachines(
                    machines = machines,
                    selectedMachines = selectedMachines,
                    onMachineToggle = { machineId ->
                        selectedMachines = if (machineId in selectedMachines) {
                            selectedMachines - machineId
                        } else {
                            selectedMachines + machineId
                        }
                    }
                )
                3 -> Step3SelectShifts(
                    selectedMachines = selectedMachines,
                    machines = machines,
                    shifts = shifts,
                    selectedShifts = selectedShifts,
                    onShiftToggle = { machineId, shiftId ->
                        val machineShifts = selectedShifts[machineId] ?: emptySet()
                        selectedShifts = selectedShifts + (machineId to if (shiftId in machineShifts) {
                            machineShifts - shiftId
                        } else {
                            machineShifts + shiftId
                        })
                    }
                )
                4 -> Step4Review(
                    selectedPageId = selectedPageId,
                    pages = pages,
                    reportHeading = reportHeading,
                    reportDate = reportDate,
                    selectedMachines = selectedMachines,
                    machines = machines,
                    selectedShifts = selectedShifts,
                    shifts = shifts
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Navigation buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (currentStep > 1) {
                    OutlinedButton(
                        onClick = { currentStep-- },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("BACK")
                    }
                }

                if (currentStep < 4) {
                    Button(
                        onClick = { currentStep++ },
                        modifier = Modifier.weight(1f),
                        enabled = isStepValid(currentStep, selectedPageId, reportHeading, selectedMachines, selectedShifts)
                    ) {
                        Text("NEXT")
                    }
                } else {
                    Button(
                        onClick = {
                            viewModel.saveReport(
                                pageId = selectedPageId ?: 1,
                                heading = reportHeading,
                                reportDate = reportDate,
                                machineIds = selectedMachines.toList(),
                                shiftsByMachine = selectedShifts
                            )
                            navController.popBackStack()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("SAVE REPORT")
                    }
                }
            }
        }
    }
}

@Composable
fun Step1BasicInfo(
    pages: List<PageEntity>,
    selectedPageId: Long?,
    onPageSelected: (Long) -> Unit,
    reportHeading: String,
    onHeadingChanged: (String) -> Unit,
    reportDate: String,
    onDateChanged: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Step 1: Basic Information", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)

        // Page selection dropdown (simplified)
        Text("Select Page:", color = MaterialTheme.colorScheme.onBackground)
        LazyColumn {
            items(pages) { page ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedPageId == page.id)
                            MaterialTheme.colorScheme.primary else
                            MaterialTheme.colorScheme.surface
                    )
                ) {
                    Text(
                        text = page.name,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        color = if (selectedPageId == page.id)
                            MaterialTheme.colorScheme.onPrimary else
                            MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }

        // Report heading
        OutlinedTextField(
            value = reportHeading,
            onValueChange = onHeadingChanged,
            label = { Text("Report Heading") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        // Date picker (simplified)
        OutlinedTextField(
            value = reportDate,
            onValueChange = onDateChanged,
            label = { Text("Report Date (yyyy-MM-dd)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
    }
}

@Composable
fun Step2SelectMachines(
    machines: List<MachineEntity>,
    selectedMachines: Set<Long>,
    onMachineToggle: (Long) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Step 2: Select Machines", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Text("Select at least 1 machine", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        LazyColumn {
            items(machines) { machine ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = machine.id in selectedMachines,
                        onCheckedChange = { onMachineToggle(machine.id) }
                    )
                    Text(
                        text = machine.name,
                        modifier = Modifier.padding(start = 8.dp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }
    }
}

@Composable
fun Step3SelectShifts(
    selectedMachines: Set<Long>,
    machines: List<MachineEntity>,
    shifts: List<ShiftEntity>,
    selectedShifts: Map<Long, Set<Long>>,
    onShiftToggle: (Long, Long) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Step 3: Select Shifts per Machine", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)

        LazyColumn {
            items(selectedMachines.toList()) { machineId ->
                val machine = machines.find { it.id == machineId }
                if (machine != null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(machine.name, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                            shifts.forEach { shift ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = shift.id in (selectedShifts[machineId] ?: emptySet()),
                                        onCheckedChange = { onShiftToggle(machineId, shift.id) }
                                    )
                                    Text(
                                        text = shift.name,
                                        modifier = Modifier.padding(start = 8.dp),
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Step4Review(
    selectedPageId: Long?,
    pages: List<PageEntity>,
    reportHeading: String,
    reportDate: String,
    selectedMachines: Set<Long>,
    machines: List<MachineEntity>,
    selectedShifts: Map<Long, Set<Long>>,
    shifts: List<ShiftEntity>
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Step 4: Review & Save", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Page: ${pages.find { it.id == selectedPageId }?.name ?: "N/A"}", color = MaterialTheme.colorScheme.onBackground)
                Text("Heading: $reportHeading", color = MaterialTheme.colorScheme.onBackground)
                Text("Date: $reportDate", color = MaterialTheme.colorScheme.onBackground)
                Text("Machines: ${selectedMachines.size}", color = MaterialTheme.colorScheme.onBackground)
                Text("Shifts: ${selectedShifts.values.sumOf { it.size }}", color = MaterialTheme.colorScheme.onBackground)
            }
        }
    }
}

private fun isStepValid(
    step: Int,
    selectedPageId: Long?,
    reportHeading: String,
    selectedMachines: Set<Long>,
    selectedShifts: Map<Long, Set<Long>>
): Boolean {
    return when (step) {
        1 -> selectedPageId != null && reportHeading.isNotBlank()
        2 -> selectedMachines.isNotEmpty()
        3 -> selectedShifts.all { (_, shifts) -> shifts.isNotEmpty() }
        else -> true
    }
}
