package com.production.dailyreport.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.production.dailyreport.data.db.ReportTemplateDao
import com.production.dailyreport.data.db.ReportTemplateEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val reportTemplateDao: ReportTemplateDao
) : ViewModel() {

    val allTemplates: Flow<List<ReportTemplateEntity>> = reportTemplateDao.getAllTemplates()

    fun setAllDatesToToday() {
        viewModelScope.launch {
            // This would update all templates to today's date
            // Implementation depends on business logic
        }
    }

    fun createNewReport(
        pageId: Long,
        heading: String,
        reportDate: String
    ) {
        viewModelScope.launch {
            val template = ReportTemplateEntity(
                pageId = pageId,
                heading = heading,
                reportDate = reportDate,
                createdAt = System.currentTimeMillis()
            )
            reportTemplateDao.insert(template)
        }
    }

    fun deleteTemplate(templateId: Long) {
        viewModelScope.launch {
            reportTemplateDao.deleteTemplateById(templateId)
        }
    }
}
