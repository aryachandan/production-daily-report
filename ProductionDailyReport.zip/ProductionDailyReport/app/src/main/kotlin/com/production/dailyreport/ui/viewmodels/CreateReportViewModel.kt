package com.production.dailyreport.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.production.dailyreport.data.db.MachineDao
import com.production.dailyreport.data.db.PageDao
import com.production.dailyreport.data.db.ReportTemplateDao
import com.production.dailyreport.data.db.ReportTemplateEntity
import com.production.dailyreport.data.db.ShiftDao
import com.production.dailyreport.data.db.TemplateMachineDao
import com.production.dailyreport.data.db.TemplateMachineEntity
import com.production.dailyreport.data.db.TemplateMachineShiftDao
import com.production.dailyreport.data.db.TemplateMachineShiftEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CreateReportViewModel @Inject constructor(
    private val pageDao: PageDao,
    private val machineDao: MachineDao,
    private val shiftDao: ShiftDao,
    private val reportTemplateDao: ReportTemplateDao,
    private val templateMachineDao: TemplateMachineDao,
    private val templateMachineShiftDao: TemplateMachineShiftDao
) : ViewModel() {

    val allPages = pageDao.getAllPages()
    val allMachines = machineDao.getAllMachines()
    val allShifts = shiftDao.getAllShifts()

    fun saveReport(
        pageId: Long,
        heading: String,
        reportDate: String,
        machineIds: List<Long>,
        shiftsByMachine: Map<Long, Set<Long>>
    ) {
        viewModelScope.launch {
            try {
                // Create report template
                val template = ReportTemplateEntity(
                    pageId = pageId,
                    heading = heading,
                    reportDate = reportDate,
                    createdAt = System.currentTimeMillis()
                )
                val templateId = reportTemplateDao.insert(template)

                // Add machines to template
                machineIds.forEachIndexed { index, machineId ->
                    val templateMachine = TemplateMachineEntity(
                        templateId = templateId,
                        machineId = machineId,
                        displayOrder = index
                    )
                    val templateMachineId = templateMachineDao.insert(templateMachine)

                    // Add shifts for this machine
                    shiftsByMachine[machineId]?.forEachIndexed { shiftIndex, shiftId ->
                        val templateMachineShift = TemplateMachineShiftEntity(
                            templateMachineId = templateMachineId,
                            shiftId = shiftId
                        )
                        templateMachineShiftDao.insert(templateMachineShift)
                    }
                }
            } catch (e: Exception) {
                // Handle error
                e.printStackTrace()
            }
        }
    }
}
