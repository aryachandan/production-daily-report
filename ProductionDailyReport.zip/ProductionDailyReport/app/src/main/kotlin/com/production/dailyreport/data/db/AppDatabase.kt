package com.production.dailyreport.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PageEntity::class,
        MachineEntity::class,
        ShiftEntity::class,
        ReportTemplateEntity::class,
        TemplateMachineEntity::class,
        TemplateMachineShiftEntity::class,
        ReportEntryEntity::class,
        PageRemarkEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun pageDao(): PageDao
    abstract fun machineDao(): MachineDao
    abstract fun shiftDao(): ShiftDao
    abstract fun reportTemplateDao(): ReportTemplateDao
    abstract fun templateMachineDao(): TemplateMachineDao
    abstract fun templateMachineShiftDao(): TemplateMachineShiftDao
    abstract fun reportEntryDao(): ReportEntryDao
    abstract fun pageRemarkDao(): PageRemarkDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "production_daily_report.db"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback : RoomDatabase.Callback() {
        override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
            super.onCreate(db)
            // Prepopulate default data
            prepopulateData(db)
        }

        private fun prepopulateData(db: androidx.sqlite.db.SupportSQLiteDatabase) {
            // Insert default pages
            val pages = listOf(
                "INSERT INTO pages (name, displayOrder) VALUES ('Stenter Report', 1)",
                "INSERT INTO pages (name, displayOrder) VALUES ('Decka Report', 2)",
                "INSERT INTO pages (name, displayOrder) VALUES ('Calender Report', 3)",
                "INSERT INTO pages (name, displayOrder) VALUES ('Folding Report', 4)",
                "INSERT INTO pages (name, displayOrder) VALUES ('Dyeing Report', 5)",
                "INSERT INTO pages (name, displayOrder) VALUES ('Water Report', 6)"
            )
            pages.forEach { db.execSQL(it) }

            // Insert default shifts
            val shifts = listOf(
                "INSERT INTO shifts (name, displayOrder) VALUES ('1ST SHIFT', 1)",
                "INSERT INTO shifts (name, displayOrder) VALUES ('2ND SHIFT', 2)"
            )
            shifts.forEach { db.execSQL(it) }

            // Insert default machines
            val machines = listOf(
                "INSERT INTO machines (name, displayOrder) VALUES ('STENTER NO.1', 1)",
                "INSERT INTO machines (name, displayOrder) VALUES ('STENTER NO.2', 2)",
                "INSERT INTO machines (name, displayOrder) VALUES ('DECKA NO.1', 3)",
                "INSERT INTO machines (name, displayOrder) VALUES ('DECKA NO.2', 4)",
                "INSERT INTO machines (name, displayOrder) VALUES ('CALENDER NO.1', 5)",
                "INSERT INTO machines (name, displayOrder) VALUES ('CALENDER NO.2', 6)",
                "INSERT INTO machines (name, displayOrder) VALUES ('CALENDER NO.3', 7)",
                "INSERT INTO machines (name, displayOrder) VALUES ('CALENDER NO.4', 8)",
                "INSERT INTO machines (name, displayOrder) VALUES ('FOLDING NO.1', 9)",
                "INSERT INTO machines (name, displayOrder) VALUES ('FOLDING NO.2', 10)",
                "INSERT INTO machines (name, displayOrder) VALUES ('FOLDING NO.3', 11)",
                "INSERT INTO machines (name, displayOrder) VALUES ('FOLDING NO.4', 12)",
                "INSERT INTO machines (name, displayOrder) VALUES ('HATH KANTI', 13)",
                "INSERT INTO machines (name, displayOrder) VALUES ('MERSERISE', 14)",
                "INSERT INTO machines (name, displayOrder) VALUES ('SOFUNA', 15)",
                "INSERT INTO machines (name, displayOrder) VALUES ('DRUM', 16)",
                "INSERT INTO machines (name, displayOrder) VALUES ('ZERO ZERO', 17)",
                "INSERT INTO machines (name, displayOrder) VALUES ('DRESS JET DYEING', 18)",
                "INSERT INTO machines (name, displayOrder) VALUES ('DRESS JIGGAR DYEING', 19)",
                "INSERT INTO machines (name, displayOrder) VALUES ('ROTTORY PRINT', 20)",
                "INSERT INTO machines (name, displayOrder) VALUES ('BORING NO.6', 21)",
                "INSERT INTO machines (name, displayOrder) VALUES ('BORING NO.7', 22)",
                "INSERT INTO machines (name, displayOrder) VALUES ('PEPL DISCHARGE', 23)"
            )
            machines.forEach { db.execSQL(it) }
        }
    }
}
