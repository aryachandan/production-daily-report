package com.production.dailyreport.ui.theme

import androidx.compose.ui.graphics.Color

// Material Design 3 Colors
val Primary = Color(0xFF2196F3)
val PrimaryDark = Color(0xFF1565C0)
val Secondary = Color(0xFF03DAC6)
val Tertiary = Color(0xFF03DAC6)

// Background & Surface
val Background = Color(0xFF0F1923)
val Surface = Color(0xFF1A2535)
val SurfaceVariant = Color(0xFF1F2D40)

// Text Colors
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB0BEC5)

// Status Colors
val Error = Color(0xFFCF6679)
val Success = Color(0xFF4CAF50)
val Warning = Color(0xFFFFC107)

// Table Colors
val GrandTotalBg = Color(0xFF1E3A5F)
val AlternatingRow1 = Color(0xFF1A2535)
val AlternatingRow2 = Color(0xFF1F2D40)
