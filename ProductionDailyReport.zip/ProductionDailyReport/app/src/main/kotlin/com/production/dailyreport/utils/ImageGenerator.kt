package com.production.dailyreport.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Environment
import androidx.core.graphics.drawText
import com.production.dailyreport.ui.viewmodels.SummaryRow
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ImageGenerator {

    fun generateReportImage(
        context: Context,
        heading: String,
        reportDate: String,
        entries: Map<String, Map<String, Long>>,
        remarks: String = "",
        companyName: String = "Production Daily Report"
    ): File? {
        return try {
            val fileName = "Report_${reportDate}_${System.currentTimeMillis()}.png"
            val file = File(
                context.getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                fileName
            )

            // Calculate dimensions
            val machineCount = entries.size
            val shiftCount = entries.values.firstOrNull()?.size ?: 2
            val rowHeight = 50
            val colWidth = 120
            val headerHeight = 200
            val footerHeight = 100

            val width = (shiftCount + 1) * colWidth + 40
            val height = headerHeight + (machineCount + 2) * rowHeight + footerHeight + 
                        (if (remarks.isNotBlank()) 100 else 0)

            // Create bitmap
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)

            var yPos = 20

            // Draw header
            yPos = drawReportHeader(canvas, companyName, heading, reportDate, yPos)

            // Draw table
            yPos = drawReportTable(canvas, entries, yPos, rowHeight, colWidth)

            // Draw remarks
            if (remarks.isNotBlank()) {
                yPos = drawRemarks(canvas, remarks, yPos)
            }

            // Draw footer
            drawReportFooter(canvas, yPos, width)

            // Save bitmap
            FileOutputStream(file).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 95, fos)
            }

            bitmap.recycle()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun generateSummaryImage(
        context: Context,
        summaryRows: List<SummaryRow>,
        grandTotal: Long,
        startDate: String,
        endDate: String,
        companyName: String = "Production Daily Report"
    ): File? {
        return try {
            val fileName = "Summary_${startDate}_to_${endDate}_${System.currentTimeMillis()}.png"
            val file = File(
                context.getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                fileName
            )

            // Calculate dimensions
            val rowHeight = 50
            val colWidth = 150
            val headerHeight = 180
            val footerHeight = 80

            val width = 5 * colWidth + 40
            val height = headerHeight + (summaryRows.size + 2) * rowHeight + footerHeight

            // Create bitmap
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)

            var yPos = 20

            // Draw header
            yPos = drawSummaryHeader(canvas, companyName, startDate, endDate, yPos)

            // Draw table
            yPos = drawSummaryTable(canvas, summaryRows, grandTotal, yPos, rowHeight, colWidth)

            // Draw footer
            drawReportFooter(canvas, yPos, width)

            // Save bitmap
            FileOutputStream(file).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 95, fos)
            }

            bitmap.recycle()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun drawReportHeader(
        canvas: Canvas,
        companyName: String,
        heading: String,
        reportDate: String,
        startY: Int
    ): Int {
        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 28f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

        val subtitlePaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 18f
            textAlign = Paint.Align.CENTER
        }

        val infoPaint = Paint().apply {
            color = Color.GRAY
            textSize = 14f
            textAlign = Paint.Align.CENTER
        }

        var yPos = startY
        canvas.drawText(companyName, canvas.width / 2f, yPos.toFloat(), titlePaint)
        yPos += 40

        canvas.drawText("Daily Production Report", canvas.width / 2f, yPos.toFloat(), subtitlePaint)
        yPos += 35

        canvas.drawText("Page: $heading", canvas.width / 2f, yPos.toFloat(), subtitlePaint)
        yPos += 35

        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        canvas.drawText("Date: $reportDate | Generated: $timestamp", canvas.width / 2f, yPos.toFloat(), infoPaint)
        yPos += 30

        // Draw divider
        val dividerPaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 2f
        }
        canvas.drawLine(20f, yPos.toFloat(), (canvas.width - 20).toFloat(), yPos.toFloat(), dividerPaint)
        yPos += 20

        return yPos
    }

    private fun drawSummaryHeader(
        canvas: Canvas,
        companyName: String,
        startDate: String,
        endDate: String,
        startY: Int
    ): Int {
        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 28f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

        val subtitlePaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 18f
            textAlign = Paint.Align.CENTER
        }

        val infoPaint = Paint().apply {
            color = Color.GRAY
            textSize = 14f
            textAlign = Paint.Align.CENTER
        }

        var yPos = startY
        canvas.drawText(companyName, canvas.width / 2f, yPos.toFloat(), titlePaint)
        yPos += 40

        canvas.drawText("Production Summary Report", canvas.width / 2f, yPos.toFloat(), subtitlePaint)
        yPos += 35

        canvas.drawText("Period: $startDate to $endDate", canvas.width / 2f, yPos.toFloat(), subtitlePaint)
        yPos += 35

        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        canvas.drawText("Generated: $timestamp", canvas.width / 2f, yPos.toFloat(), infoPaint)
        yPos += 20

        // Draw divider
        val dividerPaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 2f
        }
        canvas.drawLine(20f, yPos.toFloat(), (canvas.width - 20).toFloat(), yPos.toFloat(), dividerPaint)
        yPos += 15

        return yPos
    }

    private fun drawReportTable(
        canvas: Canvas,
        entries: Map<String, Map<String, Long>>,
        startY: Int,
        rowHeight: Int,
        colWidth: Int
    ): Int {
        val headerPaint = Paint().apply {
            color = Color.parseColor("#1565C0")
            textSize = 14f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

        val cellPaint = Paint().apply {
            color = Color.BLACK
            textSize = 12f
            textAlign = Paint.Align.CENTER
        }

        val borderPaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }

        val headerBgPaint = Paint().apply {
            color = Color.parseColor("#1565C0")
        }

        var yPos = startY

        // Draw header row
        canvas.drawRect(20f, yPos.toFloat(), (20 + colWidth * 3).toFloat(), (yPos + rowHeight).toFloat(), headerBgPaint)

        val headerText = Paint().apply {
            color = Color.WHITE
            textSize = 14f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

        canvas.drawText("Machine", (20 + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), headerText)
        canvas.drawText("Shift", (20 + colWidth + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), headerText)
        canvas.drawText("Production", (20 + colWidth * 2 + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), headerText)

        yPos += rowHeight

        // Draw data rows
        var rowIndex = 0
        var grandTotal = 0L
        entries.forEach { (machineName, shifts) ->
            shifts.forEach { (shiftName, value) ->
                val bgColor = if (rowIndex % 2 == 0) Color.WHITE else Color.parseColor("#F5F5F5")
                val bgPaint = Paint().apply { color = bgColor }

                canvas.drawRect(20f, yPos.toFloat(), (20 + colWidth * 3).toFloat(), (yPos + rowHeight).toFloat(), bgPaint)
                canvas.drawRect(20f, yPos.toFloat(), (20 + colWidth * 3).toFloat(), (yPos + rowHeight).toFloat(), borderPaint)

                canvas.drawText(machineName, (20 + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), cellPaint)
                canvas.drawText(shiftName, (20 + colWidth + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), cellPaint)
                canvas.drawText(value.toString(), (20 + colWidth * 2 + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), cellPaint)

                grandTotal += value
                yPos += rowHeight
                rowIndex++
            }
        }

        // Draw grand total row
        val totalBgPaint = Paint().apply { color = Color.parseColor("#E3F2FD") }
        canvas.drawRect(20f, yPos.toFloat(), (20 + colWidth * 3).toFloat(), (yPos + rowHeight).toFloat(), totalBgPaint)

        val totalPaint = Paint().apply {
            color = Color.parseColor("#1565C0")
            textSize = 14f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

        canvas.drawText("TOTAL", (20 + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), totalPaint)
        canvas.drawText(grandTotal.toString(), (20 + colWidth * 2 + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), totalPaint)

        yPos += rowHeight

        return yPos
    }

    private fun drawSummaryTable(
        canvas: Canvas,
        summaryRows: List<SummaryRow>,
        grandTotal: Long,
        startY: Int,
        rowHeight: Int,
        colWidth: Int
    ): Int {
        val headerPaint = Paint().apply {
            color = Color.WHITE
            textSize = 12f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

        val cellPaint = Paint().apply {
            color = Color.BLACK
            textSize = 11f
            textAlign = Paint.Align.CENTER
        }

        val borderPaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }

        val headerBgPaint = Paint().apply {
            color = Color.parseColor("#1565C0")
        }

        var yPos = startY

        // Draw header row
        val headers = listOf("Machine", "Shift", "Total", "Days", "Avg/Day")
        canvas.drawRect(20f, yPos.toFloat(), (20 + colWidth * 5).toFloat(), (yPos + rowHeight).toFloat(), headerBgPaint)

        headers.forEachIndexed { index, header ->
            canvas.drawText(header, (20 + colWidth * index + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), headerPaint)
        }

        yPos += rowHeight

        // Draw data rows
        summaryRows.forEachIndexed { rowIndex, row ->
            val bgColor = if (rowIndex % 2 == 0) Color.WHITE else Color.parseColor("#F5F5F5")
            val bgPaint = Paint().apply { color = bgColor }

            canvas.drawRect(20f, yPos.toFloat(), (20 + colWidth * 5).toFloat(), (yPos + rowHeight).toFloat(), bgPaint)
            canvas.drawRect(20f, yPos.toFloat(), (20 + colWidth * 5).toFloat(), (yPos + rowHeight).toFloat(), borderPaint)

            canvas.drawText(row.machineName, (20 + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), cellPaint)
            canvas.drawText(row.shiftName, (20 + colWidth + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), cellPaint)
            canvas.drawText(row.totalProduction.toString(), (20 + colWidth * 2 + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), cellPaint)
            canvas.drawText(row.dayCount.toString(), (20 + colWidth * 3 + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), cellPaint)
            canvas.drawText(String.format("%.1f", row.averagePerDay), (20 + colWidth * 4 + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), cellPaint)

            yPos += rowHeight
        }

        // Draw grand total row
        val totalBgPaint = Paint().apply { color = Color.parseColor("#E3F2FD") }
        canvas.drawRect(20f, yPos.toFloat(), (20 + colWidth * 5).toFloat(), (yPos + rowHeight).toFloat(), totalBgPaint)

        val totalPaint = Paint().apply {
            color = Color.parseColor("#1565C0")
            textSize = 12f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

        canvas.drawText("TOTAL", (20 + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), totalPaint)
        canvas.drawText(grandTotal.toString(), (20 + colWidth * 2 + colWidth / 2).toFloat(), (yPos + rowHeight / 2 + 5).toFloat(), totalPaint)

        yPos += rowHeight

        return yPos
    }

    private fun drawRemarks(
        canvas: Canvas,
        remarks: String,
        startY: Int
    ): Int {
        val remarkTitlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 16f
            isFakeBoldText = true
        }

        val remarkTextPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 12f
        }

        var yPos = startY + 20

        canvas.drawText("Remarks", 20f, yPos.toFloat(), remarkTitlePaint)
        yPos += 30

        val lines = remarks.split("\n")
        lines.forEach { line ->
            canvas.drawText(line, 30f, yPos.toFloat(), remarkTextPaint)
            yPos += 25
        }

        return yPos
    }

    private fun drawReportFooter(
        canvas: Canvas,
        startY: Int,
        width: Int
    ) {
        val footerPaint = Paint().apply {
            color = Color.GRAY
            textSize = 10f
            textAlign = Paint.Align.CENTER
        }

        val dividerPaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
        }

        canvas.drawLine(20f, startY.toFloat(), (width - 20).toFloat(), startY.toFloat(), dividerPaint)
        canvas.drawText("Production Daily Report v2.0", (width / 2).toFloat(), (startY + 25).toFloat(), footerPaint)
    }
}
