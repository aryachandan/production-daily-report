package com.production.dailyreport.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.production.dailyreport.data.db.MachineDao
import com.production.dailyreport.data.db.PageRemarkDao
import com.production.dailyreport.data.db.ReportEntryDao
import com.production.dailyreport.data.db.ReportEntryEntity
import com.production.dailyreport.data.db.ReportTemplateDao
import com.production.dailyreport.data.db.ShiftDao
import com.production.dailyreport.data.db.TemplateMachineDao
import com.production.dailyreport.data.db.TemplateMachineShiftDao
import com.production.dailyreport.data.db.PageRemarkEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import android.content.Context
import com.production.dailyreport.utils.PdfGenerator
import com.production.dailyreport.utils.ImageGenerator
import com.production.dailyreport.utils.ShareManager
import java.io.File

data class TableCell(
    val templateMachineShiftId: Long,
    val machineId: Long,
    val shiftId: Long,
    val machineName: String,
    val shiftName: String,
    val value: Long? = null,
    val remark: String? = null
)

data class TableRow(
    val machineId: Long,
    val machineName: String,
    val cells: List<TableCell>,
    val machineTotal: Long = 0
)

data class DataEntryState(
    val templateId: Long = 0,
    val reportDate: String = "",
    val heading: String = "",
    val rows: List<TableRow> = emptyList(),
    val columnHeaders: List<String> = emptyList(), // Shift names
    val grandTotal: Long = 0,
    val showRemarks: Boolean = false,
    val pageRemarkLine1: String = "",
    val pageRemarkLine2: String = "",
    val isLoading: Boolean = true,
    val isSaving: Boolean = false
)

@HiltViewModel
class DataEntryViewModel @Inject constructor(
    private val reportTemplateDao: ReportTemplateDao,
    private val templateMachineDao: TemplateMachineDao,
    private val templateMachineShiftDao: TemplateMachineShiftDao,
    private val reportEntryDao: ReportEntryDao,
    private val pageRemarkDao: PageRemarkDao,
    private val machineDao: MachineDao,
    private val shiftDao: ShiftDao
) : ViewModel() {

    private val _state = MutableStateFlow(DataEntryState())
    val state: StateFlow<DataEntryState> = _state.asStateFlow()

    fun loadReportData(templateId: Long) {
        viewModelScope.launch {
            try {
                // Load template
                val template = reportTemplateDao.getTemplateById(templateId)
                if (template != null) {
                    _state.value = _state.value.copy(
                        templateId = templateId,
                        reportDate = template.reportDate,
                        heading = template.heading,
                        isLoading = true
                    )

                    // Load machines for this template
                    val templateMachines = templateMachineDao.getMachinesByTemplateId(templateId)
                    val shifts = shiftDao.getAllShifts().first()

                    // Build table structure
                    val rows = mutableListOf<TableRow>()
                    val columnHeaders = shifts.map { it.name }

                    for (templateMachine in templateMachines) {
                        val machine = machineDao.getMachineById(templateMachine.machineId)
                        if (machine != null) {
                            val templateMachineShifts = templateMachineShiftDao.getShiftsByTemplateMachineId(templateMachine.id)

                            val cells = mutableListOf<TableCell>()
                            var machineTotal = 0L

                            for (templateMachineShift in templateMachineShifts) {
                                val entry = reportEntryDao.getEntry(
                                    templateMachineShift.id,
                                    template.reportDate
                                )

                                cells.add(
                                    TableCell(
                                        templateMachineShiftId = templateMachineShift.id,
                                        machineId = machine.id,
                                        shiftId = templateMachineShift.shiftId,
                                        machineName = machine.name,
                                        shiftName = shifts.find { it.id == templateMachineShift.shiftId }?.name ?: "",
                                        value = entry?.value,
                                        remark = entry?.remark
                                    )
                                )
                                machineTotal += entry?.value ?: 0
                            }

                            rows.add(
                                TableRow(
                                    machineId = machine.id,
                                    machineName = machine.name,
                                    cells = cells,
                                    machineTotal = machineTotal
                                )
                            )
                        }
                    }

                    // Load page remarks
                    val pageRemark = pageRemarkDao.getRemark(templateId, template.reportDate)

                    // Calculate grand total
                    val grandTotal = rows.sumOf { it.machineTotal }

                    _state.value = _state.value.copy(
                        rows = rows,
                        columnHeaders = columnHeaders,
                        grandTotal = grandTotal,
                        pageRemarkLine1 = pageRemark?.remarkLine1 ?: "",
                        pageRemarkLine2 = pageRemark?.remarkLine2 ?: "",
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
                _state.value = _state.value.copy(isLoading = false)
            }
        }
    }

    fun updateCellValue(templateMachineShiftId: Long, newValue: Long?) {
        viewModelScope.launch {
            try {
                val currentState = _state.value
                val reportDate = currentState.reportDate

                // Update database
                val existingEntry = reportEntryDao.getEntry(templateMachineShiftId, reportDate)
                if (existingEntry != null) {
                    reportEntryDao.update(
                        existingEntry.copy(
                            value = newValue,
                            savedAt = System.currentTimeMillis()
                        )
                    )
                } else if (newValue != null && newValue > 0) {
                    reportEntryDao.insert(
                        ReportEntryEntity(
                            templateMachineShiftId = templateMachineShiftId,
                            reportDate = reportDate,
                            value = newValue,
                            savedAt = System.currentTimeMillis()
                        )
                    )
                }

                // Recalculate totals
                recalculateTotals()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun updateCellRemark(templateMachineShiftId: Long, remark: String?) {
        viewModelScope.launch {
            try {
                val currentState = _state.value
                val reportDate = currentState.reportDate

                val existingEntry = reportEntryDao.getEntry(templateMachineShiftId, reportDate)
                if (existingEntry != null) {
                    reportEntryDao.update(
                        existingEntry.copy(
                            remark = remark,
                            savedAt = System.currentTimeMillis()
                        )
                    )
                } else {
                    reportEntryDao.insert(
                        ReportEntryEntity(
                            templateMachineShiftId = templateMachineShiftId,
                            reportDate = reportDate,
                            remark = remark,
                            savedAt = System.currentTimeMillis()
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun updatePageRemark(line1: String, line2: String) {
        viewModelScope.launch {
            try {
                val currentState = _state.value
                _state.value = _state.value.copy(
                    pageRemarkLine1 = line1,
                    pageRemarkLine2 = line2
                )

                val existingRemark = pageRemarkDao.getRemark(currentState.templateId, currentState.reportDate)
                if (existingRemark != null) {
                    pageRemarkDao.update(
                        existingRemark.copy(
                            remarkLine1 = line1,
                            remarkLine2 = line2
                        )
                    )
                } else {
                    pageRemarkDao.insert(
                        PageRemarkEntity(
                            templateId = currentState.templateId,
                            reportDate = currentState.reportDate,
                            remarkLine1 = line1,
                            remarkLine2 = line2
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun toggleShowRemarks() {
        _state.value = _state.value.copy(showRemarks = !_state.value.showRemarks)
    }

    fun clearAllData() {
        viewModelScope.launch {
            try {
                val currentState = _state.value
                reportEntryDao.deleteByDate(currentState.reportDate)
                pageRemarkDao.deleteByDate(currentState.reportDate)

                // Reload
                loadReportData(currentState.templateId)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun saveReport() {
        viewModelScope.launch {
            try {
                _state.value = _state.value.copy(isSaving = true)
                // All data is already saved via updateCellValue/updateCellRemark
                // This is just for UI feedback
                kotlinx.coroutines.delay(500)
                _state.value = _state.value.copy(isSaving = false)
            } catch (e: Exception) {
                e.printStackTrace()
                _state.value = _state.value.copy(isSaving = false)
            }
        }
    }

    fun exportToPdf(context: Context, companyName: String = "Production Daily Report"): File? {
        return try {
            val currentState = _state.value
            val entries = mutableMapOf<String, Map<String, Long>>()

            for (row in currentState.rows) {
                val shiftMap = mutableMapOf<String, Long>()
                for (cell in row.cells) {
                    shiftMap[cell.shiftName] = cell.value ?: 0
                }
                entries[row.machineName] = shiftMap
            }

            val remarks = "${currentState.pageRemarkLine1}\n${currentState.pageRemarkLine2}".trim()

            PdfGenerator.generateReportPdf(
                context = context,
                template = null,
                entries = entries,
                remarks = remarks,
                companyName = companyName
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun exportToImage(context: Context, companyName: String = "Production Daily Report"): File? {
        return try {
            val currentState = _state.value
            val entries = mutableMapOf<String, Map<String, Long>>()

            for (row in currentState.rows) {
                val shiftMap = mutableMapOf<String, Long>()
                for (cell in row.cells) {
                    shiftMap[cell.shiftName] = cell.value ?: 0
                }
                entries[row.machineName] = shiftMap
            }

            val remarks = "${currentState.pageRemarkLine1}\n${currentState.pageRemarkLine2}".trim()

            ImageGenerator.generateReportImage(
                context = context,
                heading = currentState.heading,
                reportDate = currentState.reportDate,
                entries = entries,
                remarks = remarks,
                companyName = companyName
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun shareReportImage(context: Context, companyName: String = "Production Daily Report") {
        val file = exportToImage(context, companyName)
        if (file != null) {
            ShareManager.shareFile(context, file, "Production Report", "Production Daily Report")
        }
    }

    fun shareToWhatsApp(context: Context, companyName: String = "Production Daily Report") {
        val file = exportToImage(context, companyName)
        if (file != null) {
            ShareManager.shareToWhatsApp(context, file, "Production Daily Report")
        }
    }

    private suspend fun recalculateTotals() {
        try {
            val currentState = _state.value
            val reportDate = currentState.reportDate

            // Reload all entries for this date
            val entries = reportEntryDao.getEntriesByDate(reportDate).first()

            // Recalculate rows
            val updatedRows = currentState.rows.map { row ->
                val rowTotal = row.cells.sumOf { cell ->
                    entries.find { it.templateMachineShiftId == cell.templateMachineShiftId }?.value ?: 0
                }
                row.copy(machineTotal = rowTotal)
            }

            val newGrandTotal = updatedRows.sumOf { it.machineTotal }

            _state.value = _state.value.copy(
                rows = updatedRows,
                grandTotal = newGrandTotal
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

// Extension function to get first item from Flow
suspend fun <T> kotlinx.coroutines.flow.Flow<T>.first(): T {
    var result: T? = null
    kotlinx.coroutines.flow.collect { value ->
        if (result == null) {
            result = value
        }
    }
    return result ?: throw NoSuchElementException("Flow is empty")
}
