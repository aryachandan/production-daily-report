package com.production.dailyreport.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.production.dailyreport.data.db.MachineDao
import com.production.dailyreport.data.db.MachineEntity
import com.production.dailyreport.data.db.ReportEntryDao
import com.production.dailyreport.data.db.ShiftDao
import com.production.dailyreport.data.db.ShiftEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import android.content.Context
import com.production.dailyreport.utils.PdfGenerator
import com.production.dailyreport.utils.ImageGenerator
import com.production.dailyreport.utils.ShareManager
import java.io.File

data class SummaryRow(
    val machineName: String,
    val shiftName: String,
    val totalProduction: Long,
    val dayCount: Int,
    val averagePerDay: Double
)

data class GenerateSummaryState(
    val machines: List<MachineEntity> = emptyList(),
    val shifts: List<ShiftEntity> = emptyList(),
    val selectedMachines: Set<Long> = emptySet(),
    val selectedShifts: Set<Long> = emptySet(),
    val startDate: String = "",
    val endDate: String = "",
    val summaryRows: List<SummaryRow> = emptyList(),
    val grandTotal: Long = 0,
    val isLoading: Boolean = true,
    val showSummary: Boolean = false,
    val dateRangeMode: String = "custom" // "custom", "monthly", "yearly"
)

@HiltViewModel
class GenerateSummaryViewModel @Inject constructor(
    private val machineDao: MachineDao,
    private val shiftDao: ShiftDao,
    private val reportEntryDao: ReportEntryDao
) : ViewModel() {

    private val _state = MutableStateFlow(GenerateSummaryState())
    val state: StateFlow<GenerateSummaryState> = _state.asStateFlow()

    init {
        loadMachinesAndShifts()
    }

    private fun loadMachinesAndShifts() {
        viewModelScope.launch {
            try {
                val machines = machineDao.getAllMachines()
                val shifts = shiftDao.getAllShifts()

                _state.value = _state.value.copy(
                    machines = machines,
                    shifts = shifts,
                    isLoading = false
                )
            } catch (e: Exception) {
                e.printStackTrace()
                _state.value = _state.value.copy(isLoading = false)
            }
        }
    }

    fun toggleMachineSelection(machineId: Long) {
        val updated = _state.value.selectedMachines.toMutableSet()
        if (updated.contains(machineId)) {
            updated.remove(machineId)
        } else {
            updated.add(machineId)
        }
        _state.value = _state.value.copy(selectedMachines = updated)
    }

    fun toggleShiftSelection(shiftId: Long) {
        val updated = _state.value.selectedShifts.toMutableSet()
        if (updated.contains(shiftId)) {
            updated.remove(shiftId)
        } else {
            updated.add(shiftId)
        }
        _state.value = _state.value.copy(selectedShifts = updated)
    }

    fun setStartDate(date: String) {
        _state.value = _state.value.copy(startDate = date)
    }

    fun setEndDate(date: String) {
        _state.value = _state.value.copy(endDate = date)
    }

    fun setDateRangeMode(mode: String) {
        _state.value = _state.value.copy(dateRangeMode = mode)
        
        // Auto-calculate dates based on mode
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val calendar = java.util.Calendar.getInstance()
        
        when (mode) {
            "monthly" -> {
                calendar.set(java.util.Calendar.DAY_OF_MONTH, 1)
                val startDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.time)
                _state.value = _state.value.copy(startDate = startDate, endDate = today)
            }
            "yearly" -> {
                calendar.set(java.util.Calendar.MONTH, 0)
                calendar.set(java.util.Calendar.DAY_OF_MONTH, 1)
                val startDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.time)
                _state.value = _state.value.copy(startDate = startDate, endDate = today)
            }
        }
    }

    fun selectAllMachines() {
        _state.value = _state.value.copy(
            selectedMachines = _state.value.machines.map { it.id }.toSet()
        )
    }

    fun deselectAllMachines() {
        _state.value = _state.value.copy(selectedMachines = emptySet())
    }

    fun selectAllShifts() {
        _state.value = _state.value.copy(
            selectedShifts = _state.value.shifts.map { it.id }.toSet()
        )
    }

    fun deselectAllShifts() {
        _state.value = _state.value.copy(selectedShifts = emptySet())
    }

    fun generateSummary() {
        viewModelScope.launch {
            try {
                if (_state.value.selectedMachines.isEmpty() || _state.value.selectedShifts.isEmpty()) {
                    return@launch
                }

                val startDate = _state.value.startDate
                val endDate = _state.value.endDate

                // Fetch entries for selected machines and shifts in date range
                val entries = reportEntryDao.getEntriesByDateRange(startDate, endDate)

                // Group and calculate
                val summaryMap = mutableMapOf<Pair<Long, Long>, MutableList<Long>>() // (machineId, shiftId) -> [values]

                for (entry in entries) {
                    if (_state.value.selectedMachines.contains(entry.machineId) &&
                        _state.value.selectedShifts.contains(entry.shiftId)) {
                        val key = Pair(entry.machineId, entry.shiftId)
                        summaryMap.getOrPut(key) { mutableListOf() }.add(entry.value ?: 0)
                    }
                }

                // Build summary rows
                val rows = mutableListOf<SummaryRow>()
                var grandTotal = 0L

                for ((key, values) in summaryMap) {
                    val machineId = key.first
                    val shiftId = key.second
                    val machineName = _state.value.machines.find { it.id == machineId }?.name ?: "Unknown"
                    val shiftName = _state.value.shifts.find { it.id == shiftId }?.name ?: "Unknown"
                    val totalProduction = values.sum()
                    val dayCount = values.size
                    val averagePerDay = if (dayCount > 0) totalProduction.toDouble() / dayCount else 0.0

                    rows.add(
                        SummaryRow(
                            machineName = machineName,
                            shiftName = shiftName,
                            totalProduction = totalProduction,
                            dayCount = dayCount,
                            averagePerDay = averagePerDay
                        )
                    )
                    grandTotal += totalProduction
                }

                _state.value = _state.value.copy(
                    summaryRows = rows.sortedWith(compareBy({ it.machineName }, { it.shiftName })),
                    grandTotal = grandTotal,
                    showSummary = true
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun resetSummary() {
        _state.value = _state.value.copy(
            summaryRows = emptyList(),
            grandTotal = 0,
            showSummary = false
        )
    }

    fun exportSummaryToPdf(context: Context, companyName: String = "Production Daily Report"): File? {
        return try {
            PdfGenerator.generateSummaryPdf(
                context = context,
                summaryRows = _state.value.summaryRows,
                grandTotal = _state.value.grandTotal,
                startDate = _state.value.startDate,
                endDate = _state.value.endDate,
                companyName = companyName
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun exportSummaryToImage(context: Context, companyName: String = "Production Daily Report"): File? {
        return try {
            ImageGenerator.generateSummaryImage(
                context = context,
                summaryRows = _state.value.summaryRows,
                grandTotal = _state.value.grandTotal,
                startDate = _state.value.startDate,
                endDate = _state.value.endDate,
                companyName = companyName
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun shareSummaryImage(context: Context, companyName: String = "Production Daily Report") {
        val file = exportSummaryToImage(context, companyName)
        if (file != null) {
            ShareManager.shareFile(context, file, "Production Summary", "Production Summary Report")
        }
    }

    fun shareToWhatsApp(context: Context, companyName: String = "Production Daily Report") {
        val file = exportSummaryToImage(context, companyName)
        if (file != null) {
            ShareManager.shareToWhatsApp(context, file, "Production Summary Report")
        }
    }
}

// Extension to fetch entries by date range
suspend fun com.production.dailyreport.data.db.ReportEntryDao.getEntriesByDateRange(
    startDate: String,
    endDate: String
): List<com.production.dailyreport.data.db.ReportEntryEntity> {
    val entries = mutableListOf<com.production.dailyreport.data.db.ReportEntryEntity>()
    // This would need to be implemented in the DAO
    return entries
}
