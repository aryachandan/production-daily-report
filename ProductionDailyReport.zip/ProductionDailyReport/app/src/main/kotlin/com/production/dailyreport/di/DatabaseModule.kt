package com.production.dailyreport.di

import android.content.Context
import com.production.dailyreport.data.db.AppDatabase
import com.production.dailyreport.data.db.PageDao
import com.production.dailyreport.data.db.MachineDao
import com.production.dailyreport.data.db.ShiftDao
import com.production.dailyreport.data.db.ReportTemplateDao
import com.production.dailyreport.data.db.TemplateMachineDao
import com.production.dailyreport.data.db.TemplateMachineShiftDao
import com.production.dailyreport.data.db.ReportEntryDao
import com.production.dailyreport.data.db.PageRemarkDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Singleton
    @Provides
    fun provideAppDatabase(
        @ApplicationContext context: Context
    ): AppDatabase {
        return AppDatabase.getDatabase(context)
    }

    @Singleton
    @Provides
    fun providePageDao(database: AppDatabase): PageDao {
        return database.pageDao()
    }

    @Singleton
    @Provides
    fun provideMachineDao(database: AppDatabase): MachineDao {
        return database.machineDao()
    }

    @Singleton
    @Provides
    fun provideShiftDao(database: AppDatabase): ShiftDao {
        return database.shiftDao()
    }

    @Singleton
    @Provides
    fun provideReportTemplateDao(database: AppDatabase): ReportTemplateDao {
        return database.reportTemplateDao()
    }

    @Singleton
    @Provides
    fun provideTemplateMachineDao(database: AppDatabase): TemplateMachineDao {
        return database.templateMachineDao()
    }

    @Singleton
    @Provides
    fun provideTemplateMachineShiftDao(database: AppDatabase): TemplateMachineShiftDao {
        return database.templateMachineShiftDao()
    }

    @Singleton
    @Provides
    fun provideReportEntryDao(database: AppDatabase): ReportEntryDao {
        return database.reportEntryDao()
    }

    @Singleton
    @Provides
    fun providePageRemarkDao(database: AppDatabase): PageRemarkDao {
        return database.pageRemarkDao()
    }
}
