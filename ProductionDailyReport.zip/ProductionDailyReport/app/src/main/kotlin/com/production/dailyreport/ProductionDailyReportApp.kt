package com.production.dailyreport

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ProductionDailyReportApp : Application()
