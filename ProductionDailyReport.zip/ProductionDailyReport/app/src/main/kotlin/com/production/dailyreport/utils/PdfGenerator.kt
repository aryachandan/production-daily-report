package com.production.dailyreport.utils

import android.content.Context
import android.os.Environment
import com.itextpdf.io.font.PdfEncodings
import com.itextpdf.kernel.colors.ColorConstants
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.borders.Border
import com.itextpdf.layout.borders.SolidBorder
import com.itextpdf.layout.element.Cell
import com.itextpdf.layout.element.Paragraph
import com.itextpdf.layout.element.Table
import com.itextpdf.layout.properties.HorizontalAlignment
import com.itextpdf.layout.properties.TextAlignment
import com.itextpdf.layout.properties.UnitValue
import com.production.dailyreport.data.db.ReportTemplateEntity
import com.production.dailyreport.ui.viewmodels.SummaryRow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfGenerator {

    fun generateReportPdf(
        context: Context,
        template: ReportTemplateEntity,
        entries: Map<String, Map<String, Long>>, // machineId -> shiftId -> value
        remarks: String = "",
        companyName: String = "Production Daily Report"
    ): File? {
        return try {
            val fileName = "Report_${template.reportDate}_${System.currentTimeMillis()}.pdf"
            val file = File(
                context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
                fileName
            )

            val writer = PdfWriter(file)
            val pdfDocument = PdfDocument(writer)
            val document = Document(pdfDocument)

            // Add header
            addReportHeader(document, companyName, template.reportDate, template.heading)

            // Add table with entries
            addEntriesTable(document, entries, template.heading)

            // Add remarks if present
            if (remarks.isNotBlank()) {
                addRemarksSection(document, remarks)
            }

            // Add footer
            addReportFooter(document)

            document.close()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun generateSummaryPdf(
        context: Context,
        summaryRows: List<SummaryRow>,
        grandTotal: Long,
        startDate: String,
        endDate: String,
        companyName: String = "Production Daily Report"
    ): File? {
        return try {
            val fileName = "Summary_${startDate}_to_${endDate}_${System.currentTimeMillis()}.pdf"
            val file = File(
                context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
                fileName
            )

            val writer = PdfWriter(file)
            val pdfDocument = PdfDocument(writer)
            val document = Document(pdfDocument)

            // Add header
            addSummaryHeader(document, companyName, startDate, endDate)

            // Add summary table
            addSummaryTable(document, summaryRows, grandTotal)

            // Add footer
            addReportFooter(document)

            document.close()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun addReportHeader(
        document: Document,
        companyName: String,
        reportDate: String,
        heading: String
    ) {
        // Company Name
        document.add(
            Paragraph(companyName)
                .setFontSize(18f)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(4f)
        )

        // Report Title
        document.add(
            Paragraph("Daily Production Report")
                .setFontSize(14f)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(4f)
        )

        // Page/Heading
        document.add(
            Paragraph("Page: $heading")
                .setFontSize(12f)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(4f)
        )

        // Date and Timestamp
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        document.add(
            Paragraph("Date: $reportDate | Generated: $timestamp")
                .setFontSize(10f)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(12f)
        )

        // Divider
        document.add(
            Paragraph("─".repeat(80))
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(12f)
        )
    }

    private fun addSummaryHeader(
        document: Document,
        companyName: String,
        startDate: String,
        endDate: String
    ) {
        // Company Name
        document.add(
            Paragraph(companyName)
                .setFontSize(18f)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(4f)
        )

        // Report Title
        document.add(
            Paragraph("Production Summary Report")
                .setFontSize(14f)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(4f)
        )

        // Date Range
        document.add(
            Paragraph("Period: $startDate to $endDate")
                .setFontSize(12f)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(4f)
        )

        // Timestamp
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        document.add(
            Paragraph("Generated: $timestamp")
                .setFontSize(10f)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(12f)
        )

        // Divider
        document.add(
            Paragraph("─".repeat(80))
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(12f)
        )
    }

    private fun addEntriesTable(
        document: Document,
        entries: Map<String, Map<String, Long>>,
        heading: String
    ) {
        // Create table with dynamic columns
        val columnCount = 3 // Machine, Shift, Value
        val table = Table(UnitValue.createPercentArray(floatArrayOf(40f, 30f, 30f)))
        table.setWidth(UnitValue.createPercentValue(100f))

        // Header row
        val headerCells = listOf("Machine", "Shift", "Production")
        headerCells.forEach { headerText ->
            val cell = Cell()
                .add(Paragraph(headerText).setBold())
                .setBackgroundColor(ColorConstants.LIGHT_GRAY)
                .setTextAlignment(TextAlignment.CENTER)
                .setPadding(6f)
            table.addCell(cell)
        }

        // Data rows
        var rowIndex = 0
        entries.forEach { (machineId, shifts) ->
            shifts.forEach { (shiftId, value) ->
                val bgColor = if (rowIndex % 2 == 0) ColorConstants.WHITE else ColorConstants.LIGHT_GRAY

                // Machine ID
                table.addCell(
                    Cell()
                        .add(Paragraph(machineId))
                        .setBackgroundColor(bgColor)
                        .setPadding(4f)
                )

                // Shift ID
                table.addCell(
                    Cell()
                        .add(Paragraph(shiftId))
                        .setBackgroundColor(bgColor)
                        .setPadding(4f)
                )

                // Value
                table.addCell(
                    Cell()
                        .add(Paragraph(value.toString()).setBold())
                        .setBackgroundColor(bgColor)
                        .setTextAlignment(TextAlignment.RIGHT)
                        .setPadding(4f)
                )

                rowIndex++
            }
        }

        document.add(table)
        document.add(Paragraph("\n"))
    }

    private fun addSummaryTable(
        document: Document,
        summaryRows: List<SummaryRow>,
        grandTotal: Long
    ) {
        // Create table
        val table = Table(UnitValue.createPercentArray(floatArrayOf(25f, 20f, 20f, 15f, 20f)))
        table.setWidth(UnitValue.createPercentValue(100f))

        // Header row
        val headers = listOf("Machine", "Shift", "Total", "Days", "Avg/Day")
        headers.forEach { headerText ->
            val cell = Cell()
                .add(Paragraph(headerText).setBold())
                .setBackgroundColor(ColorConstants.LIGHT_GRAY)
                .setTextAlignment(TextAlignment.CENTER)
                .setPadding(6f)
            table.addCell(cell)
        }

        // Data rows
        summaryRows.forEachIndexed { index, row ->
            val bgColor = if (index % 2 == 0) ColorConstants.WHITE else ColorConstants.LIGHT_GRAY

            table.addCell(
                Cell()
                    .add(Paragraph(row.machineName))
                    .setBackgroundColor(bgColor)
                    .setPadding(4f)
            )

            table.addCell(
                Cell()
                    .add(Paragraph(row.shiftName))
                    .setBackgroundColor(bgColor)
                    .setPadding(4f)
            )

            table.addCell(
                Cell()
                    .add(Paragraph(row.totalProduction.toString()).setBold())
                    .setBackgroundColor(bgColor)
                    .setTextAlignment(TextAlignment.RIGHT)
                    .setPadding(4f)
            )

            table.addCell(
                Cell()
                    .add(Paragraph(row.dayCount.toString()))
                    .setBackgroundColor(bgColor)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setPadding(4f)
            )

            table.addCell(
                Cell()
                    .add(Paragraph(String.format("%.1f", row.averagePerDay)))
                    .setBackgroundColor(bgColor)
                    .setTextAlignment(TextAlignment.RIGHT)
                    .setPadding(4f)
            )
        }

        // Grand Total row
        val grandTotalBgColor = ColorConstants.LIGHT_GRAY
        table.addCell(
            Cell()
                .add(Paragraph("TOTAL").setBold())
                .setBackgroundColor(grandTotalBgColor)
                .setPadding(6f)
        )

        table.addCell(
            Cell()
                .add(Paragraph(""))
                .setBackgroundColor(grandTotalBgColor)
        )

        table.addCell(
            Cell()
                .add(Paragraph(grandTotal.toString()).setBold())
                .setBackgroundColor(grandTotalBgColor)
                .setTextAlignment(TextAlignment.RIGHT)
                .setPadding(6f)
        )

        table.addCell(
            Cell()
                .add(Paragraph(""))
                .setBackgroundColor(grandTotalBgColor)
        )

        table.addCell(
            Cell()
                .add(Paragraph(""))
                .setBackgroundColor(grandTotalBgColor)
        )

        document.add(table)
        document.add(Paragraph("\n"))
    }

    private fun addRemarksSection(document: Document, remarks: String) {
        document.add(
            Paragraph("Remarks")
                .setBold()
                .setFontSize(12f)
                .setMarginTop(12f)
                .setMarginBottom(4f)
        )

        document.add(
            Paragraph(remarks)
                .setFontSize(10f)
                .setMarginBottom(12f)
        )
    }

    private fun addReportFooter(document: Document) {
        document.add(
            Paragraph("─".repeat(80))
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginTop(12f)
                .setMarginBottom(4f)
        )

        document.add(
            Paragraph("Production Daily Report v2.0")
                .setFontSize(9f)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(ColorConstants.GRAY)
        )
    }
}
