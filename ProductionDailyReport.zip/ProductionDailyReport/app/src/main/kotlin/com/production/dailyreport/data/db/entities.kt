package com.production.dailyreport.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

/**
 * Page Entity - Represents a report page (e.g., "Stenter Report", "Decka Report")
 */
@Entity(tableName = "pages")
data class PageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val displayOrder: Int
)

/**
 * Machine Entity - Represents a machine (e.g., "STENTER NO.1", "DECKA NO.2")
 */
@Entity(tableName = "machines")
data class MachineEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val displayOrder: Int
)

/**
 * Shift Entity - Represents a shift (e.g., "1ST SHIFT", "2ND SHIFT")
 */
@Entity(tableName = "shifts")
data class ShiftEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val displayOrder: Int
)

/**
 * ReportTemplate Entity - Represents the structure of a report
 */
@Entity(tableName = "report_templates")
data class ReportTemplateEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val pageId: Long,
    val heading: String,
    val reportDate: String, // ISO format "yyyy-MM-dd"
    val createdAt: Long // epoch ms
)

/**
 * TemplateMachine Entity - Represents a machine in a report template
 */
@Entity(
    tableName = "template_machines",
    foreignKeys = [
        ForeignKey(
            entity = ReportTemplateEntity::class,
            parentColumns = ["id"],
            childColumns = ["templateId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = MachineEntity::class,
            parentColumns = ["id"],
            childColumns = ["machineId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class TemplateMachineEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val templateId: Long,
    val machineId: Long,
    val displayOrder: Int
)

/**
 * TemplateMachineShift Entity - Represents a shift for a machine in a template
 */
@Entity(
    tableName = "template_machine_shifts",
    foreignKeys = [
        ForeignKey(
            entity = TemplateMachineEntity::class,
            parentColumns = ["id"],
            childColumns = ["templateMachineId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ShiftEntity::class,
            parentColumns = ["id"],
            childColumns = ["shiftId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class TemplateMachineShiftEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val templateMachineId: Long,
    val shiftId: Long
)

/**
 * ReportEntry Entity - Represents the actual production data entry
 */
@Entity(
    tableName = "report_entries",
    foreignKeys = [
        ForeignKey(
            entity = TemplateMachineShiftEntity::class,
            parentColumns = ["id"],
            childColumns = ["templateMachineShiftId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ReportEntryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val templateMachineShiftId: Long,
    val reportDate: String, // "yyyy-MM-dd"
    val value: Long? = null, // production quantity
    val remark: String? = null, // per-shift remark
    val savedAt: Long // epoch ms
)

/**
 * PageRemark Entity - Represents general remarks for a page/report
 */
@Entity(
    tableName = "page_remarks",
    foreignKeys = [
        ForeignKey(
            entity = ReportTemplateEntity::class,
            parentColumns = ["id"],
            childColumns = ["templateId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class PageRemarkEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val templateId: Long,
    val reportDate: String,
    val remarkLine1: String? = null,
    val remarkLine2: String? = null
)
