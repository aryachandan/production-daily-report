package com.production.dailyreport.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.production.dailyreport.data.db.ReportEntryDao
import com.production.dailyreport.data.db.ReportTemplateDao
import com.production.dailyreport.data.db.ReportTemplateEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HistoryState(
    val templates: List<ReportTemplateEntity> = emptyList(),
    val isLoading: Boolean = true,
    val filterPageId: Long? = null,
    val filterDate: String? = null
)

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val reportTemplateDao: ReportTemplateDao,
    private val reportEntryDao: ReportEntryDao
) : ViewModel() {

    private val _state = MutableStateFlow(HistoryState())
    val state: StateFlow<HistoryState> = _state.asStateFlow()

    fun loadHistory() {
        viewModelScope.launch {
            try {
                _state.value = _state.value.copy(isLoading = true)
                val templates = reportTemplateDao.getAllTemplates()
                _state.value = _state.value.copy(
                    templates = templates.sortedByDescending { it.createdAt },
                    isLoading = false
                )
            } catch (e: Exception) {
                e.printStackTrace()
                _state.value = _state.value.copy(isLoading = false)
            }
        }
    }

    fun deleteTemplate(templateId: Long) {
        viewModelScope.launch {
            try {
                // Delete all entries for this template
                reportEntryDao.deleteByTemplateId(templateId)
                // Delete the template
                reportTemplateDao.delete(templateId)
                // Reload
                loadHistory()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun filterByPage(pageId: Long) {
        _state.value = _state.value.copy(filterPageId = pageId)
        loadHistory()
    }

    fun filterByDate(date: String) {
        _state.value = _state.value.copy(filterDate = date)
        loadHistory()
    }

    fun clearFilters() {
        _state.value = _state.value.copy(filterPageId = null, filterDate = null)
        loadHistory()
    }
}
