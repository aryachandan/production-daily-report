package com.production.dailyreport.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.production.dailyreport.ui.theme.AlternatingRow1
import com.production.dailyreport.ui.theme.AlternatingRow2
import com.production.dailyreport.ui.theme.GrandTotalBg
import com.production.dailyreport.ui.viewmodels.DataEntryViewModel

@Composable
fun DataEntryScreen(
    navController: NavHostController,
    templateId: Long,
    viewModel: DataEntryViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(templateId) {
        viewModel.loadReportData(templateId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.heading) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { paddingValues ->
        if (state.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState())
            ) {
                // Date and info bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Date: ${state.reportDate}",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = state.showRemarks,
                            onCheckedChange = { viewModel.toggleShowRemarks() }
                        )
                        Text(
                            text = "Show Remarks",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Dynamic Table
                DynamicTable(
                    state = state,
                    onCellValueChange = { templateMachineShiftId, value ->
                        viewModel.updateCellValue(templateMachineShiftId, value)
                    },
                    onCellRemarkChange = { templateMachineShiftId, remark ->
                        viewModel.updateCellRemark(templateMachineShiftId, remark)
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Page Remarks Section
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "General Remarks",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        OutlinedTextField(
                            value = state.pageRemarkLine1,
                            onValueChange = {
                                viewModel.updatePageRemark(it, state.pageRemarkLine2)
                            },
                            label = { Text("Remark Line 1") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = state.pageRemarkLine2,
                            onValueChange = {
                                viewModel.updatePageRemark(state.pageRemarkLine1, it)
                            },
                            label = { Text("Remark Line 2") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.clearAllData() },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Delete, contentDescription = "Clear", modifier = Modifier.padding(end = 4.dp))
                        Text("CLEAR")
                    }

                    Button(
                        onClick = { viewModel.saveReport() },
                        modifier = Modifier.weight(1f),
                        enabled = !state.isSaving
                    ) {
                        if (state.isSaving) {
                            CircularProgressIndicator(
                                modifier = Modifier.width(16.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        } else {
                            Text("SAVE")
                        }
                    }

                    Button(
                        onClick = { viewModel.exportToPdf(navController.context) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("PDF")
                    }

                    Button(
                        onClick = { viewModel.shareReportImage(navController.context) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Share")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun DynamicTable(
    state: com.production.dailyreport.ui.viewmodels.DataEntryState,
    onCellValueChange: (Long, Long?) -> Unit,
    onCellRemarkChange: (Long, String?) -> Unit
) {
    val horizontalScroll = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(horizontalScroll)
            .padding(horizontal = 12.dp)
    ) {
        // Header Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(4.dp)
        ) {
            // Machine name column header
            Box(
                modifier = Modifier
                    .width(120.dp)
                    .height(40.dp)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Machine",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimary,
                    textAlign = TextAlign.Center
                )
            }

            // Shift column headers
            state.columnHeaders.forEach { shiftName ->
                Box(
                    modifier = Modifier
                        .width(80.dp)
                        .height(40.dp)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = shiftName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Machine Total column header
            Box(
                modifier = Modifier
                    .width(80.dp)
                    .height(40.dp)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Total",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimary,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Data Rows
        state.rows.forEachIndexed { rowIndex, row ->
            val backgroundColor = if (rowIndex % 2 == 0) AlternatingRow1 else AlternatingRow2

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(backgroundColor)
                    .padding(4.dp)
            ) {
                // Machine name cell
                Box(
                    modifier = Modifier
                        .width(120.dp)
                        .height(60.dp)
                        .background(backgroundColor),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = row.machineName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(4.dp)
                    )
                }

                // Data cells
                row.cells.forEach { cell ->
                    TableDataCell(
                        cell = cell,
                        showRemark = state.showRemarks,
                        onValueChange = { newValue ->
                            onCellValueChange(cell.templateMachineShiftId, newValue)
                        },
                        onRemarkChange = { newRemark ->
                            onCellRemarkChange(cell.templateMachineShiftId, newRemark)
                        }
                    )
                }

                // Machine Total cell
                Box(
                    modifier = Modifier
                        .width(80.dp)
                        .height(60.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = row.machineTotal.toString(),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(1.dp))
        }

        // Grand Total Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(GrandTotalBg)
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(120.dp)
                    .height(50.dp)
                    .background(GrandTotalBg),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "GRAND TOTAL",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
                )
            }

            // Empty cells for shifts
            repeat(state.columnHeaders.size) {
                Box(
                    modifier = Modifier
                        .width(80.dp)
                        .height(50.dp)
                        .background(GrandTotalBg)
                )
            }

            // Grand Total value
            Box(
                modifier = Modifier
                    .width(80.dp)
                    .height(50.dp)
                    .background(GrandTotalBg),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = state.grandTotal.toString(),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun TableDataCell(
    cell: com.production.dailyreport.ui.viewmodels.TableCell,
    showRemark: Boolean,
    onValueChange: (Long?) -> Unit,
    onRemarkChange: (String?) -> Unit
) {
    var valueText by remember { mutableStateOf(cell.value?.toString() ?: "") }
    var remarkText by remember { mutableStateOf(cell.remark ?: "") }

    Column(
        modifier = Modifier
            .width(80.dp)
            .background(MaterialTheme.colorScheme.surface)
            .padding(2.dp)
    ) {
        // Value input
        OutlinedTextField(
            value = valueText,
            onValueChange = { newValue ->
                valueText = newValue
                onValueChange(newValue.toLongOrNull())
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(if (showRemark) 32.dp else 60.dp)
                .padding(2.dp),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            textStyle = androidx.compose.material3.MaterialTheme.typography.labelSmall.copy(
                textAlign = TextAlign.Center
            )
        )

        // Remark input (if visible)
        if (showRemark) {
            OutlinedTextField(
                value = remarkText,
                onValueChange = { newValue ->
                    remarkText = newValue
                    onRemarkChange(if (newValue.isBlank()) null else newValue)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .padding(2.dp),
                singleLine = true,
                textStyle = androidx.compose.material3.MaterialTheme.typography.labelSmall.copy(
                    textAlign = TextAlign.Center,
                    fontSize = 9.sp
                )
            )
        }
    }
}
