package com.production.dailyreport.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.production.dailyreport.ui.viewmodels.SettingsViewModel

@Composable
fun SettingsScreen(navController: NavHostController) {
    SettingsScreenFull(navController)
}

@Composable
fun SettingsScreenFull(
    navController: NavHostController,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { paddingValues ->
        if (state.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
            ) {
                // Tab Row
                TabRow(
                    selectedTabIndex = state.selectedTab,
                    modifier = Modifier.fillMaxWidth(),
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    Tab(
                        selected = state.selectedTab == 0,
                        onClick = { viewModel.selectTab(0) },
                        text = { Text("Pages") }
                    )
                    Tab(
                        selected = state.selectedTab == 1,
                        onClick = { viewModel.selectTab(1) },
                        text = { Text("Machines") }
                    )
                    Tab(
                        selected = state.selectedTab == 2,
                        onClick = { viewModel.selectTab(2) },
                        text = { Text("Shifts") }
                    )
                    Tab(
                        selected = state.selectedTab == 3,
                        onClick = { viewModel.selectTab(3) },
                        text = { Text("Cleanup") }
                    )
                    Tab(
                        selected = state.selectedTab == 4,
                        onClick = { viewModel.selectTab(4) },
                        text = { Text("Reminders") }
                    )
                }

                // Tab Content
                when (state.selectedTab) {
                    0 -> PagesTab(state, viewModel)
                    1 -> MachinesTab(state, viewModel)
                    2 -> ShiftsTab(state, viewModel)
                    3 -> CleanupTab(state, viewModel)
                    4 -> RemindersTab(state, viewModel, navController.context)
                }
            }
        }
    }

    // Add/Edit Dialog
    if (state.showAddDialog) {
        AddEditDialog(
            title = when (state.selectedTab) {
                0 -> if (state.editingItemId != null) "Edit Page" else "Add Page"
                1 -> if (state.editingItemId != null) "Edit Machine" else "Add Machine"
                2 -> if (state.editingItemId != null) "Edit Shift" else "Add Shift"
                else -> "Add Item"
            },
            itemName = state.newItemName,
            onNameChange = { viewModel.updateNewItemName(it) },
            onConfirm = {
                when (state.selectedTab) {
                    0 -> {
                        if (state.editingItemId != null) {
                            viewModel.updatePage(state.editingItemId!!, state.newItemName)
                        } else {
                            viewModel.addPage(state.newItemName)
                        }
                    }
                    1 -> {
                        if (state.editingItemId != null) {
                            viewModel.updateMachine(state.editingItemId!!, state.newItemName)
                        } else {
                            viewModel.addMachine(state.newItemName)
                        }
                    }
                    2 -> {
                        if (state.editingItemId != null) {
                            viewModel.updateShift(state.editingItemId!!, state.newItemName)
                        } else {
                            viewModel.addShift(state.newItemName)
                        }
                    }
                }
            },
            onDismiss = { viewModel.hideAddDialog() }
        )
    }

    // Delete Confirmation Dialog
    if (state.showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.hideDeleteDialog() },
            title = { Text("Delete Item") },
            text = { Text("Delete \"${state.selectedItemName}\"? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        when (state.selectedTab) {
                            0 -> viewModel.deletePage(state.selectedItemId)
                            1 -> viewModel.deleteMachine(state.selectedItemId)
                            2 -> viewModel.deleteShift(state.selectedItemId)
                        }
                    }
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.hideDeleteDialog() }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun PagesTab(state: com.production.dailyreport.ui.viewmodels.SettingsState, viewModel: SettingsViewModel) {
    Column(modifier = Modifier.fillMaxSize()) {
        Button(
            onClick = { viewModel.showAddDialog("page") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Add", modifier = Modifier.padding(end = 4.dp))
            Text("Add Page")
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.pages) { page ->
                ItemCard(
                    name = page.name,
                    onEdit = { viewModel.startEditingItem(page.id, page.name) },
                    onDelete = { viewModel.showDeleteDialog(page.id, page.name) }
                )
            }
        }
    }
}

@Composable
fun MachinesTab(state: com.production.dailyreport.ui.viewmodels.SettingsState, viewModel: SettingsViewModel) {
    Column(modifier = Modifier.fillMaxSize()) {
        Button(
            onClick = { viewModel.showAddDialog("machine") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Add", modifier = Modifier.padding(end = 4.dp))
            Text("Add Machine")
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.machines) { machine ->
                ItemCard(
                    name = machine.name,
                    onEdit = { viewModel.startEditingItem(machine.id, machine.name) },
                    onDelete = { viewModel.showDeleteDialog(machine.id, machine.name) }
                )
            }
        }
    }
}

@Composable
fun ShiftsTab(state: com.production.dailyreport.ui.viewmodels.SettingsState, viewModel: SettingsViewModel) {
    Column(modifier = Modifier.fillMaxSize()) {
        Button(
            onClick = { viewModel.showAddDialog("shift") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Add", modifier = Modifier.padding(end = 4.dp))
            Text("Add Shift")
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.shifts) { shift ->
                ItemCard(
                    name = shift.name,
                    onEdit = { viewModel.startEditingItem(shift.id, shift.name) },
                    onDelete = { viewModel.showDeleteDialog(shift.id, shift.name) }
                )
            }
        }
    }
}

@Composable
fun CleanupTab(state: com.production.dailyreport.ui.viewmodels.SettingsState, viewModel: SettingsViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Data Cleanup",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Delete Old Entries",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Remove production entries older than the selected period.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.deleteEntriesOlderThan(30) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("30 days")
                    }
                    OutlinedButton(
                        onClick = { viewModel.deleteEntriesOlderThan(90) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("90 days")
                    }
                    OutlinedButton(
                        onClick = { viewModel.deleteEntriesOlderThan(180) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("6 months")
                    }
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "⚠️ Danger Zone",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.error
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Delete ALL production entries. This cannot be undone.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { viewModel.deleteEntriesOlderThan(0) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("Delete All Data")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "About",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Production Daily Report v2.0",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Built for textile factories",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun ItemCard(
    name: String,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = name,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f)
            )

            Row {
                IconButton(onClick = onEdit) {
                    Icon(
                        Icons.Filled.Edit,
                        contentDescription = "Edit",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.width(20.dp)
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        Icons.Filled.Delete,
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.width(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AddEditDialog(
    title: String,
    itemName: String,
    onNameChange: (String) -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = itemName,
                onValueChange = onNameChange,
                label = { Text("Name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = itemName.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}


// Reminders Tab
@Composable
fun RemindersTab(
    state: SettingsState,
    viewModel: SettingsViewModel,
    context: android.content.Context
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Daily Reminder",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Enable Daily Reminder",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "Get notified to fill your production report",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.loadReminders(context)
                            viewModel.toggleReminder(context)
                        },
                        modifier = Modifier.width(100.dp)
                    ) {
                        Text(if (state.reminderEnabled) "ON" else "OFF")
                    }
                }
            }
        }

        if (state.reminderEnabled) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.showTimePickerDialog() }
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "Reminder Time",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "Tap to change time",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Text(
                            String.format("%02d:%02d", state.reminderHour, state.reminderMinute),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            item {
                Text(
                    "You will receive a notification at ${String.format("%02d:%02d", state.reminderHour, state.reminderMinute)} every day",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Time Picker Dialog
    if (state.showTimePickerDialog) {
        TimePickerDialog(
            hour = state.reminderHour,
            minute = state.reminderMinute,
            onTimeSelected = { hour, minute ->
                viewModel.setReminderTime(context, hour, minute)
            },
            onDismiss = { viewModel.hideTimePickerDialog() }
        )
    }
}

// Time Picker Dialog
@Composable
fun TimePickerDialog(
    hour: Int,
    minute: Int,
    onTimeSelected: (Int, Int) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedHour by androidx.compose.runtime.remember { mutableStateOf(hour) }
    var selectedMinute by androidx.compose.runtime.remember { mutableStateOf(minute) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Reminder Time") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Hour", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = { selectedHour = (selectedHour - 1 + 24) % 24 },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("-")
                            }
                            Text(
                                String.format("%02d", selectedHour),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            OutlinedButton(
                                onClick = { selectedHour = (selectedHour + 1) % 24 },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("+")
                            }
                        }
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Minute", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = { selectedMinute = (selectedMinute - 5 + 60) % 60 },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("-")
                            }
                            Text(
                                String.format("%02d", selectedMinute),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            OutlinedButton(
                                onClick = { selectedMinute = (selectedMinute + 5) % 60 },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("+")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onTimeSelected(selectedHour, selectedMinute) }) {
                Text("Set")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
