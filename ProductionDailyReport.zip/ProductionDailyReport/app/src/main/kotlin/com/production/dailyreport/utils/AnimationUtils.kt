package com.production.dailyreport.utils

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.EaseInOutCubic
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment

object AnimationUtils {

    // Standard animation durations
    const val DURATION_SHORT = 150
    const val DURATION_MEDIUM = 300
    const val DURATION_LONG = 500

    // Screen transitions
    fun slideInFromRight(): EnterTransition {
        return slideInHorizontally(
            initialOffsetX = { it },
            animationSpec = tween(DURATION_MEDIUM, easing = EaseInOutCubic)
        ) + fadeIn(animationSpec = tween(DURATION_MEDIUM))
    }

    fun slideOutToLeft(): ExitTransition {
        return slideOutHorizontally(
            targetOffsetX = { -it },
            animationSpec = tween(DURATION_MEDIUM, easing = EaseInOutCubic)
        ) + fadeOut(animationSpec = tween(DURATION_MEDIUM))
    }

    fun slideInFromLeft(): EnterTransition {
        return slideInHorizontally(
            initialOffsetX = { -it },
            animationSpec = tween(DURATION_MEDIUM, easing = EaseInOutCubic)
        ) + fadeIn(animationSpec = tween(DURATION_MEDIUM))
    }

    fun slideOutToRight(): ExitTransition {
        return slideOutHorizontally(
            targetOffsetX = { it },
            animationSpec = tween(DURATION_MEDIUM, easing = EaseInOutCubic)
        ) + fadeOut(animationSpec = tween(DURATION_MEDIUM))
    }

    fun slideInFromBottom(): EnterTransition {
        return slideInVertically(
            initialOffsetY = { it },
            animationSpec = tween(DURATION_MEDIUM, easing = EaseInOutCubic)
        ) + fadeIn(animationSpec = tween(DURATION_MEDIUM))
    }

    fun slideOutToBottom(): ExitTransition {
        return slideOutVertically(
            targetOffsetY = { it },
            animationSpec = tween(DURATION_MEDIUM, easing = EaseInOutCubic)
        ) + fadeOut(animationSpec = tween(DURATION_MEDIUM))
    }

    // Expand/collapse animations
    fun expandAnimation(): EnterTransition {
        return expandVertically(
            expandFrom = Alignment.Top,
            animationSpec = tween(DURATION_MEDIUM, easing = EaseInOutCubic)
        ) + fadeIn(animationSpec = tween(DURATION_MEDIUM))
    }

    fun collapseAnimation(): ExitTransition {
        return shrinkVertically(
            shrinkTowards = Alignment.Top,
            animationSpec = tween(DURATION_MEDIUM, easing = EaseInOutCubic)
        ) + fadeOut(animationSpec = tween(DURATION_MEDIUM))
    }

    // Fade animations
    fun fadeInAnimation(): EnterTransition {
        return fadeIn(animationSpec = tween(DURATION_SHORT, easing = EaseInOutCubic))
    }

    fun fadeOutAnimation(): ExitTransition {
        return fadeOut(animationSpec = tween(DURATION_SHORT, easing = EaseInOutCubic))
    }
}

@Composable
fun AnimatedVisibilityWithSlide(
    visible: Boolean,
    content: @Composable () -> Unit
) {
    AnimatedVisibility(
        visible = visible,
        enter = AnimationUtils.slideInFromBottom(),
        exit = AnimationUtils.slideOutToBottom(),
        content = { content() }
    )
}

@Composable
fun AnimatedVisibilityWithExpand(
    visible: Boolean,
    content: @Composable () -> Unit
) {
    AnimatedVisibility(
        visible = visible,
        enter = AnimationUtils.expandAnimation(),
        exit = AnimationUtils.collapseAnimation(),
        content = { content() }
    )
}

@Composable
fun AnimatedVisibilityWithFade(
    visible: Boolean,
    content: @Composable () -> Unit
) {
    AnimatedVisibility(
        visible = visible,
        enter = AnimationUtils.fadeInAnimation(),
        exit = AnimationUtils.fadeOutAnimation(),
        content = { content() }
    )
}
