# Production Daily Report - User Guide

## Welcome to Production Daily Report v2.0

Production Daily Report is a professional Android application designed for textile factories to track daily production data efficiently. This guide will help you get started and use all features of the app.

## Getting Started

### First Launch

When you open the app for the first time, you'll see the **Onboarding Screen** with 3 helpful slides:

1. **Slide 1**: Overview of the app's purpose
2. **Slide 2**: Key features explanation
3. **Slide 3**: Quick tips for best use

You can either tap **SKIP** to go directly to the app, or **GET STARTED** to complete the onboarding. You won't see this again unless you reset the app.

### Home Screen

The **Home Screen** is your main dashboard. Here you can:

- **View Reports**: See all your daily production reports in card format
- **Create New Report**: Tap the floating action button (FAB) to create a new report
- **Access History**: View past reports by tapping the History icon
- **Configure Settings**: Tap the Settings icon to customize the app
- **Generate Summary**: Tap the Chart icon to view analytics and summaries

## Creating a Daily Report

### Step 1: Select Page

When you tap the **FAB** button, you'll enter the **Create Report** wizard:

1. Select which **Page** (production area/line) you're reporting for
2. The dropdown shows all available pages (default: 6 pages pre-configured)
3. Tap **NEXT** to proceed

### Step 2: Select Machines

1. Choose which **Machines** to include in this report
2. Use **Select All** to quickly select all machines
3. Use **Clear** to deselect all machines
4. Tap **NEXT** to proceed

### Step 3: Select Shifts

1. Choose which **Shifts** to include (typically 1ST SHIFT, 2ND SHIFT, etc.)
2. Use **Select All** or **Clear** buttons as needed
3. Tap **NEXT** to proceed

### Step 4: Review & Save

1. Review your selections (Page, Machines, Shifts)
2. Tap **SAVE** to create the report
3. You'll automatically navigate to the **Data Entry Screen**

## Entering Production Data

### Data Entry Screen

The **Data Entry Screen** shows a professional table with:

- **Rows**: All selected machines
- **Columns**: All selected shifts
- **Cells**: Input fields for production numbers

### How to Enter Data

1. **Tap any cell** to enter production data
2. **Type the number** (numeric input only)
3. **Press Enter** or tap outside to confirm
4. **Auto-calculations** update instantly:
   - Machine totals (sum of all shifts)
   - Shift totals (sum of all machines)
   - Grand total (sum of everything)

### Remarks (Notes)

1. **Toggle Remarks Column**: Use the checkbox in the table header to show/hide remarks
2. **Add Notes**: Tap the remark cell to add notes about that machine/shift
3. **General Remarks**: Add page-level notes at the bottom (2 lines available)

### Saving Your Data

1. **SAVE Button**: Saves all data to the database
2. **CLEAR Button**: Resets all data with confirmation (use carefully!)
3. **PDF Button**: Exports the report as a PDF file
4. **SHARE Button**: Shares the report as an image

## Exporting & Sharing Reports

### PDF Export

1. Tap the **PDF** button on the Data Entry screen
2. A PDF file is generated with:
   - Report header (company name, date, timestamp)
   - Production table with all data
   - Remarks section (if any)
3. The PDF is saved to your device's Documents folder
4. You can open it with any PDF viewer

### Image Export

1. Tap the **SHARE** button on the Data Entry screen
2. An image (PNG) is generated showing the production table
3. The Android Share Sheet opens with options to share via:
   - **WhatsApp**: Send to contacts or groups
   - **Email**: Attach to email message
   - **Telegram**: Share with contacts
   - **Other Apps**: Any app that accepts image sharing

### Sharing Steps

1. Select the app you want to share with
2. The image is automatically attached
3. Add any message you want
4. Send!

## Viewing History

### History Screen

The **History Screen** shows all your past reports:

1. Reports are sorted by date (newest first)
2. Each card shows:
   - Report heading (page name)
   - Creation date and time
3. **Tap any report** to view/edit the data
4. **Delete button** removes the report with confirmation

### Filtering History

Currently, all reports are shown. Future versions will include filtering by date range or page.

## Settings & Configuration

### Pages Management

1. Go to **Settings** → **Pages Tab**
2. **Add Page**: Enter page name and tap Add
3. **Edit Page**: Tap Edit button, change name, tap Save
4. **Delete Page**: Tap Delete button with confirmation

### Machines Management

1. Go to **Settings** → **Machines Tab**
2. **Add Machine**: Enter machine name and tap Add
3. **Edit Machine**: Tap Edit button, change name, tap Save
4. **Delete Machine**: Tap Delete button with confirmation

### Shifts Management

1. Go to **Settings** → **Shifts Tab**
2. **Add Shift**: Enter shift name (e.g., "3RD SHIFT") and tap Add
3. **Edit Shift**: Tap Edit button, change name, tap Save
4. **Delete Shift**: Tap Delete button with confirmation

### Data Cleanup

1. Go to **Settings** → **Cleanup Tab**
2. Choose how many days back to delete:
   - **Delete 30 days**: Remove reports older than 30 days
   - **Delete 90 days**: Remove reports older than 90 days
   - **Delete 6 months**: Remove reports older than 6 months
   - **Delete ALL**: Remove all reports (use with caution!)
3. Tap the delete button with confirmation

### Daily Reminders

1. Go to **Settings** → **Reminders Tab**
2. **Enable Reminder**: Tap the ON/OFF button to enable
3. **Set Time**: Tap the time card to open time picker
4. **Adjust Time**: Use +/- buttons to set hour and minute
5. **Confirm**: Tap SET to save the time
6. You'll receive a notification every day at that time

## Generating Summary Reports

### Summary Screen

The **Generate Summary Screen** lets you analyze production data:

1. **Select Date Range**:
   - **Custom**: Choose specific start and end dates
   - **Monthly**: Get data for a specific month
   - **Yearly**: Get data for a specific year

2. **Select Machines**: Choose which machines to include
   - Use **Select All** to include all
   - Use **Clear** to deselect all

3. **Select Shifts**: Choose which shifts to include
   - Use **Select All** to include all
   - Use **Clear** to deselect all

4. **Generate**: Tap to create the summary

### Summary Results

The summary table shows:

- **Machine**: Machine name
- **Shift**: Shift name
- **Total**: Total production for this machine/shift combination
- **Days**: Number of days with data
- **Avg/Day**: Average production per day

The **Grand Total Row** (highlighted) shows overall totals.

### Exporting Summary

1. **PDF Button**: Export summary as PDF document
2. **SHARE Button**: Share summary as image

## Tips & Best Practices

### Data Entry Tips

1. **Use Tab Key**: Press Tab to move to the next cell quickly
2. **Numeric Input**: Only numbers are accepted (0-9)
3. **Auto-Save**: Data is automatically saved when you tap SAVE
4. **Remarks**: Always add remarks for unusual production numbers

### Organization Tips

1. **Name Pages Clearly**: Use production line names (e.g., "LINE A", "LINE B")
2. **Name Machines Clearly**: Use machine numbers or names (e.g., "MACHINE 01")
3. **Consistent Shift Names**: Keep shift names consistent (e.g., "1ST SHIFT", "2ND SHIFT")
4. **Regular Backups**: Export reports as PDF for backup

### Sharing Tips

1. **Use WhatsApp Groups**: Share daily summaries with team leads
2. **Email Reports**: Send daily reports to management
3. **Archive PDFs**: Keep PDF copies for compliance/audit
4. **Image Quality**: PNG images are high-resolution and suitable for all platforms

## Troubleshooting

### App Won't Start

1. Force stop the app: Settings → Apps → Production Daily Report → Force Stop
2. Clear app data: Settings → Apps → Production Daily Report → Storage → Clear Data
3. Reinstall the app

### Data Not Saving

1. Check if you tapped the **SAVE** button
2. Check if you have storage space available
3. Restart the app and try again

### Notifications Not Appearing

1. Check notification settings: Settings → Apps → Production Daily Report → Notifications
2. Enable notifications if disabled
3. Check system notification settings for the app

### PDF/Image Export Not Working

1. Check if you have storage permission enabled
2. Check if you have enough storage space
3. Try again after restarting the app

### Share Not Working

1. Ensure the target app (WhatsApp, Email, etc.) is installed
2. Grant file access permissions if prompted
3. Try a different sharing app

## FAQ

**Q: Can I edit a past report?**
A: Yes! Go to History, tap the report, and edit the data. Changes are saved automatically.

**Q: Can I delete a report?**
A: Yes! Go to History, tap the delete button on the report card, and confirm.

**Q: Can I backup my data?**
A: Currently, data is stored locally. Export reports as PDF for backup. Future versions will include cloud backup.

**Q: Can I use this on multiple devices?**
A: Currently, data is device-specific. Future versions will include cloud sync.

**Q: How do I reset the app?**
A: Go to Settings → Cleanup → Delete ALL. This removes all data and resets to defaults.

**Q: Can I customize the default pages/machines/shifts?**
A: Yes! Go to Settings and use the Pages, Machines, and Shifts tabs to add, edit, or delete items.

**Q: How often should I backup my data?**
A: We recommend exporting important reports as PDF daily or weekly.

**Q: Is my data secure?**
A: Data is stored locally on your device. No data is sent to external servers. Future versions will include encrypted cloud backup.

## Contact & Support

For technical support or feature requests, please contact the development team.

---

**Version**: 2.0.0  
**Last Updated**: 2026-03-05  
**Minimum Android Version**: 7.0 (API 24)  
**Target Android Version**: 14.0 (API 34)
