# Production Daily Report - Android App v2.0

A native Android application for textile factory production reporting using Kotlin and Jetpack Compose.

## Tech Stack

- **Language**: Kotlin
- **UI Framework**: Jetpack Compose (Material Design 3)
- **Architecture**: MVVM + Repository Pattern
- **Database**: Room DB with 8 entities
- **Async**: Kotlin Coroutines + StateFlow
- **Dependency Injection**: Hilt
- **Min SDK**: API 24 (Android 7.0)
- **Target SDK**: API 34 (Android 14)

## Project Structure

```
ProductionDailyReport/
├── app/
│   ├── src/main/
│   │   ├── kotlin/com/production/dailyreport/
│   │   │   ├── ProductionDailyReportApp.kt          (Hilt entry point)
│   │   │   ├── MainActivity.kt                      (Compose entry point)
│   │   │   ├── data/
│   │   │   │   └── db/
│   │   │   │       ├── entities.kt                  (8 Room entities)
│   │   │   │       ├── daos.kt                      (8 DAOs)
│   │   │   │       └── AppDatabase.kt               (Room database)
│   │   │   ├── di/
│   │   │   │   └── DatabaseModule.kt                (Hilt DI configuration)
│   │   │   ├── ui/
│   │   │   │   ├── theme/
│   │   │   │   │   ├── Color.kt                     (Material Design 3 colors)
│   │   │   │   │   ├── Theme.kt                     (Theme configuration)
│   │   │   │   │   └── Type.kt                      (Typography)
│   │   │   │   ├── screens/
│   │   │   │   │   ├── SplashScreen.kt              (1.5s splash with onboarding check)
│   │   │   │   │   ├── OnboardingScreen.kt          (3-slide ViewPager onboarding)
│   │   │   │   │   ├── HomeScreen.kt                (Report cards list + FAB)
│   │   │   │   │   └── CreateReportScreen.kt        (4-step form wizard)
│   │   │   │   ├── viewmodels/
│   │   │   │   │   ├── HomeViewModel.kt
│   │   │   │   │   └── CreateReportViewModel.kt
│   │   │   │   └── navigation/
│   │   │   │       └── AppNavigation.kt             (Compose navigation graph)
│   │   ├── res/
│   │   │   ├── values/
│   │   │   │   ├── strings.xml
│   │   │   │   ├── themes.xml
│   │   │   │   └── colors.xml
│   │   │   └── xml/
│   │   │       └── file_paths.xml                   (FileProvider config)
│   │   └── AndroidManifest.xml
│   ├── build.gradle.kts                             (App dependencies)
│   └── proguard-rules.pro
├── build.gradle.kts                                 (Root build config)
├── settings.gradle.kts
└── README.md

```

## Database Schema

### Entities (8 total)
1. **PageEntity** - Report pages (e.g., "Stenter Report")
2. **MachineEntity** - Machines (e.g., "STENTER NO.1")
3. **ShiftEntity** - Shifts (e.g., "1ST SHIFT")
4. **ReportTemplateEntity** - Report structure
5. **TemplateMachineEntity** - Machines in a report
6. **TemplateMachineShiftEntity** - Shifts per machine
7. **ReportEntryEntity** - Production data entries
8. **PageRemarkEntity** - General remarks

### Default Data (Pre-populated)
- **Pages**: Stenter, Decka, Calender, Folding, Dyeing, Water
- **Machines**: 23 machines (STENTER NO.1-2, DECKA NO.1-2, etc.)
- **Shifts**: 1ST SHIFT, 2ND SHIFT

## Screens Implemented (5/9)

✅ **Splash Screen** (Phase 3)
- 1.5 second splash with app branding
- Checks SharedPreferences for onboarding completion
- Navigates to Onboarding or Home

✅ **Onboarding Screen** (Phase 3)
- 3-slide horizontal pager
- SKIP button (top-right) → Home
- NEXT button → next slide
- GET STARTED button (last slide) → Home + saves flag
- Dot indicators showing current slide
- Back button for non-first slides

✅ **Home Screen** (Phase 4)
- Top bar with Settings icon
- "Set All Dates to Today" button
- Report cards list (full-width, 120dp height)
- Empty state with illustration
- FAB (+) button → Create Report
- Bottom Navigation placeholder

✅ **Create Report Screen** (Phase 5)
- Step 1: Select Page, Enter Heading, Select Date
- Step 2: Multi-select Machines (min 1 required)
- Step 3: Multi-select Shifts per Machine (min 1 per machine)
- Step 4: Review & Save
- Navigation between steps with BACK/NEXT buttons
- Form validation

## Screens To Be Built (4/9)

⏳ **Data Entry Screen** (Phase 6)
- Dynamic table with machines × shifts
- Real-time total calculations
- Remark toggle (show/hide remark column)
- CLEAR, SAVE, SEND buttons
- Upsert logic for daily entries

⏳ **History Screen** (Phase 7)
- Filter by Page and Date
- List of past reports
- Tap to view/edit

⏳ **History Detail Screen** (Phase 7)
- Same as Data Entry but with UPDATE button
- DELETE ENTRY button

⏳ **Settings Screen** (Phase 8)
- Manage Pages (add/edit/delete)
- Manage Machines (add/edit/delete)
- Manage Shifts (add/edit/delete)
- Generate Summary Report
- Data Cleanup (delete 90 days / by date range)
- About section

⏳ **Generate Summary Screen** (Phase 9)
- Select Machines (multi-select)
- Select Shifts (multi-select)
- Date range or monthly picker
- Generate analytics report

## Features To Be Implemented (5/9)

⏳ **PDF Export** (Phase 10)
- iText7 library
- Embedded Noto Sans Devanagari font for Hindi
- Professional table layout with formatting
- Remark fields (only if non-empty)

⏳ **Image Export** (Phase 11)
- Canvas-based rendering
- 1080px+ width
- Share via Intent

⏳ **Share Sheet** (Phase 11)
- Android ShareCompat integration
- FileProvider for file sharing
- Works with WhatsApp, Email, Telegram, etc.

⏳ **Daily Reminders** (Phase 12)
- WorkManager + NotificationManager
- User-configurable time
- Notification taps open app to Home

⏳ **Material Design 3 Styling** (Phase 13)
- Dark theme (already applied)
- Animations (FAB hide on scroll, expand/collapse remarks)
- Ripple effects

## Building & Running

### Prerequisites
- Android Studio Iguana or later
- JDK 17+
- Gradle 8.2+

### Build Steps
```bash
# Clone/extract project
cd ProductionDailyReport

# Build debug APK
./gradlew assembleDebug

# Build release APK (unsigned)
./gradlew assembleRelease

# Run on emulator/device
./gradlew installDebug
```

### APK Locations
- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release-unsigned.apk`

## Development Progress

**Session 1 (Current):**
- ✅ Project scaffold with Gradle, Hilt, Compose
- ✅ Room database (8 entities, DAOs, pre-population)
- ✅ Theme & colors (Material Design 3 dark)
- ✅ Navigation graph
- ✅ Splash, Onboarding, Home, Create Report screens
- ✅ ViewModels for Home and CreateReport
- 📋 Next: Data Entry screen with dynamic table

**Future Sessions:**
- Session 2: Data Entry, History, History Detail screens
- Session 3: Settings, Generate Summary screens
- Session 4: PDF/Image export with iText7
- Session 5: Share Sheet, Notifications, final polish

## Notes

- All data persists in Room DB (survives app restart and phone restart)
- Onboarding shown only once (stored in SharedPreferences)
- Default machines/pages/shifts pre-populated on first install
- No internet required (fully offline)
- Supports Android 7.0+ (API 24+)

## Creator

**Chandan Kumar Mishra**  
Email: aryachandanmishra@gmail.com

---

*Production Daily Report v2.0 - Native Android App*
